# Smart P&ID Creator - User Guide

## Table of Contents

1. [Getting Started](#getting-started)
2. [Creating a P&ID](#creating-a-pid)
3. [Using the Canvas](#using-the-canvas)
4. [Editing Components](#editing-components)
5. [Working with Connections](#working-with-connections)
6. [Exporting](#exporting)
7. [Tips & Tricks](#tips--tricks)

---

## Getting Started

### Accessing the Application

1. Open your web browser
2. Navigate to `http://localhost:3000`
3. You'll see the home page with options to:
   - Create New P&ID
   - View Projects

### System Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- Minimum screen resolution: 1366x768
- Internet connection (for AI features)

---

## Creating a P&ID

### Method 1: Using the Wizard (Recommended)

The wizard guides you through creating a P&ID step-by-step.

#### Step 1: Project Information

1. Click **"Create New P&ID"** from the home page
2. Fill in:
   - **Project Name**: A descriptive name for your project
   - **Description**: Optional project description
   - **Industry Type**: Select your industry (Chemical, Oil & Gas, etc.)
   - **Standard**: Choose P&ID standard (ISA S5.1, ISO 10628, etc.)
3. Click **"Save & Continue"**

#### Step 2: Process Description

1. **Option A: Use a Template**
   - Click one of the template cards:
     - 🔄 Mixing Process
     - 🏭 Distillation
     - ❄️ Cooling Water
   - Template text will fill the description area

2. **Option B: Write Your Own**
   - Describe your process in plain English
   - Example:
     ```
     A mixing process where two feed streams are combined.

     Raw material from Tank T-101 is pumped by Pump P-101A/B
     to the mixing vessel V-101. A second stream from Tank T-102
     is pumped by P-102 into the mixer.

     The mixed product flows by gravity to storage Tank T-103.
     Flow and temperature measurements are required.
     ```

3. **Tips for Good Descriptions**:
   - Mention all major equipment (tanks, pumps, reactors)
   - Describe the flow sequence from start to finish
   - Include fluid types and conditions
   - Note control or safety requirements

4. Click **"Save & Continue"**

#### Step 3: Equipment Specification

1. **Auto-Extract Equipment** (Recommended):
   - Click **"🤖 Auto-Extract Equipment from Description"**
   - AI will analyze your description and suggest equipment
   - Review the suggested equipment in the table

2. **Add Equipment Manually**:
   - Click **"+ Add Equipment Manually"**
   - Fill in:
     - **Tag**: Equipment identifier (e.g., P-101, T-201)
     - **Type**: Equipment type (pump, tank, vessel, etc.)
     - **Description**: Brief description
   - Click **"Add"**

3. **Edit or Remove**:
   - Click **"Remove"** to delete equipment
   - Equipment table shows Tag, Type, and Description

4. Click **"Next"** when done

#### Step 4: Review & Generate

1. **Review Summary**:
   - Check project information
   - Review process description
   - Verify equipment list

2. **Generate P&ID**:
   - Click **"🚀 Generate Smart P&ID"**
   - Watch the progress bar:
     - Creating project...
     - Starting P&ID generation...
     - Analyzing process description...
     - Designing equipment layout...
     - Optimizing layout...
     - Generating output...

3. **Wait for Completion** (30-60 seconds):
   - Progress bar shows completion percentage
   - Current step displays what's happening
   - Don't close the page during generation

4. **Auto-Navigation**:
   - When complete, you'll be taken to the editor
   - Your P&ID will be displayed on the canvas

---

## Using the Canvas

### Overview

The canvas is where your P&ID is displayed and edited.

**Canvas Layout**:
- **Left**: Main canvas area with grid
- **Right**: Component inspector panel
- **Top**: Toolbar with save/export buttons
- **Bottom-Right**: Zoom controls

### Navigation

#### Pan (Move Around)
- **Click and drag** on empty canvas area
- **Mouse**: Click and hold, then drag
- **Trackpad**: Two-finger drag

#### Zoom
- **Mouse Wheel**: Scroll up to zoom in, down to zoom out
- **Zoom Buttons** (bottom-right):
  - **+** : Zoom in
  - **−** : Zoom out
  - **Percentage button**: Reset to 100%

#### Grid
- Visual grid helps align components
- Major gridlines every 100px
- Minor gridlines every 25px
- Snap-to-grid (future feature)

### Selecting Components

**Select a Component**:
- Click on any equipment, valve, or line
- Selected item will be highlighted in blue
- Inspector panel updates with properties

**Deselect**:
- Click on empty canvas area
- Press **Escape** key (future feature)

### Moving Components

**Drag and Drop**:
1. Click on a component to select it
2. Click and hold on the component
3. Drag to new position
4. Release mouse button
5. Position is automatically saved

**Precise Positioning**:
- Use inspector panel "Position" section
- Enter exact X and Y coordinates
- Useful for alignment

### Canvas Stats

- **Top-left corner** shows:
  - **Components**: Number of equipment/valves
  - **Lines**: Number of connections
- Updates in real-time as you edit

---

## Editing Components

### Component Inspector Panel

Located on the right side when a component is selected.

#### Tabs

1. **⚙️ Properties**: Edit component specifications
2. **🔗 Connections**: View incoming/outgoing lines
3. **📝 Notes**: Add notes and documentation

### Properties Tab

#### Basic Information

- **Tag Number**: Component identifier (e.g., P-101)
  - Click to edit
  - Must be unique
  - Follow standard naming (P for pumps, T for tanks, etc.)

- **Type**: Component type (read-only)
  - Shows: pump, tank, heat exchanger, etc.

#### Component-Specific Properties

**For Pumps**:
- Capacity (m³/h)
- Head (m)
- Power (kW)
- Efficiency (%)
- NPSH Required (m)
- Material
- Seal Type
- Driver
- Spared (checkbox)

**For Tanks**:
- Volume (m³)
- Diameter (m)
- Height (m)
- Design Pressure (bar)
- Design Temperature (°C)
- Material
- Insulation

**For Heat Exchangers**:
- Duty (kW)
- Heat Transfer Area (m²)
- Shell Material
- Tube Material
- Shell Design Pressure (bar)
- Tube Design Pressure (bar)

#### Position

- **X**: Horizontal position (pixels)
- **Y**: Vertical position (pixels)
- Edit for precise placement

#### How to Edit

1. Select component on canvas
2. Click **Properties** tab
3. Click in any field
4. Type new value
5. Press **Enter** or click outside field
6. Changes save automatically

### Connections Tab

Shows lines connected to the selected component.

#### Incoming Connections
- Lines flowing INTO this component
- Shows:
  - Line number
  - Type (process, utility, instrument)
  - From which component
  - Fluid service
  - Line size

#### Outgoing Connections
- Lines flowing OUT OF this component
- Shows same information as incoming

#### Add Connection
- Click **"+ Add Connection"**
- Future feature for creating lines

### Notes Tab

Add notes, comments, or documentation.

#### Add a Note
1. Type in text area
2. Click **"Add Note"**
3. Note appears in yellow card below

#### Delete a Note
- Click **✕** button on note card

#### Documents
- **"+ Upload Document"** button
- Future feature for attaching:
  - Datasheets
  - Manuals
  - Specifications
  - Drawings

### Component Actions

Located at bottom of inspector:

- **Delete**: Remove component from P&ID
  - Also removes connected lines
  - Cannot be undone (yet)

- **Duplicate**: Create a copy (future feature)

---

## Working with Connections

### Understanding Connections

**Connection Types** (shown by line style):
- **Process** (solid black): Main process piping
- **Utility** (dashed green): Utility lines (water, air, etc.)
- **Instrument** (dashed red): Instrument signals
- **Signal** (dotted purple): Control signals

### Viewing Connection Details

1. **Click on a line** to select it
2. Inspector shows connection properties
3. **Line label** shows line number
4. **Arrows** indicate flow direction

### Connection Properties

When a line is selected:
- Line number
- Type (process, utility, etc.)
- From/To components
- Fluid service
- Line size
- Piping class
- Material

---

## Exporting

### Export Options

Located in top-right toolbar:

#### Save
- **Button**: "Save"
- Saves current P&ID to database
- Preserves all component positions and properties
- Can be reopened later

#### Export to JSON
- **Button**: "Export"
- Downloads P&ID as JSON file
- Includes all components and connections
- Can be imported into other systems
- Useful for backup

#### Export to PDF (Coming Soon)
- Vector PDF for printing
- High-quality diagrams
- Preserves all symbols and text

#### Export to DXF (Coming Soon)
- CAD format (AutoCAD compatible)
- For use in CAD software
- Engineering documentation

### Exporting Reports (Coming Soon)

- **Equipment List**: Excel table of all equipment
- **Line List**: Piping specifications
- **Instrument Index**: All instruments
- **I/O List**: Control system inputs/outputs

---

## Tips & Tricks

### General Tips

1. **Save Frequently**: Click "Save" button often
2. **Use Templates**: Start with templates and modify
3. **Descriptive Tags**: Use clear, standard tag numbers
4. **Consistent Naming**: Follow industry standards (ISA, ISO)
5. **Add Notes**: Document decisions and requirements

### Performance Tips

1. **Zoom Out for Overview**: See entire diagram
2. **Zoom In for Details**: Edit specific components
3. **Use Grid**: Align components visually
4. **Group Related Equipment**: Place close together

### Wizard Tips

1. **Detailed Descriptions**: More detail = better AI extraction
2. **Mention Equipment Tags**: "Tank T-101" vs just "tank"
3. **Describe Flow**: "From tank to pump to reactor"
4. **Include Properties**: "Design pressure 10 bar"

### Canvas Tips

1. **Select Before Edit**: Click component first
2. **Drag Smoothly**: Hold down mouse while dragging
3. **Use Zoom Controls**: Bottom-right buttons
4. **Watch Component Count**: Top-left stats

### Property Editing Tips

1. **Use Standard Units**: m³/h, bar, °C, kW
2. **Be Consistent**: Same units throughout
3. **Add Details**: More properties = better documentation
4. **Use Notes Tab**: For special requirements

### Keyboard Shortcuts (Future)

- **Ctrl+S**: Save
- **Ctrl+Z**: Undo
- **Ctrl+Y**: Redo
- **Delete**: Delete selected component
- **Escape**: Deselect
- **Ctrl+D**: Duplicate

---

## Troubleshooting

### Common Issues

**Problem**: Can't see canvas
- **Solution**: Try zooming out (click percentage button)

**Problem**: Component won't move
- **Solution**: Make sure it's selected (blue outline)

**Problem**: Changes not saving
- **Solution**: Click "Save" button in toolbar

**Problem**: Canvas is laggy
- **Solution**: Close other browser tabs, reduce zoom

**Problem**: Generation failed
- **Solution**: Check wizard data, try simpler description

### Getting Help

- **Documentation**: Check docs folder
- **Examples**: See examples/ directory
- **Issues**: Report at GitHub Issues
- **Community**: Join Discord (coming soon)

---

## What's Next?

### Learn More

- [API Documentation](../README_NEW.md#api-documentation)
- [Architecture Guide](./ARCHITECTURE.md)
- [Example Templates](../examples/)

### Advanced Features

- Real-time collaboration
- Version control
- Custom symbol libraries
- Integration with other systems
- YOLOv5 symbol detection

---

**Need Help?** Check the [README](../README_NEW.md) or [SETUP Guide](../SETUP.md)

**Happy designing! 🎨🏭**
