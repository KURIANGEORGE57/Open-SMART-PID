# Smart P&ID Creator - API Documentation

## Base URL

```
http://localhost:8000/api/v1
```

## Authentication

Currently, the API does not require authentication. Future versions will support JWT tokens.

## Response Format

All API responses follow this format:

**Success Response:**
```json
{
  "id": "uuid",
  "name": "Example",
  ...
}
```

**Error Response:**
```json
{
  "detail": "Error message"
}
```

---

## Projects API

### Create Project

Create a new P&ID project.

**Endpoint:** `POST /projects`

**Request Body:**
```json
{
  "name": "My Process Plant",
  "description": "A chemical processing facility",
  "industry_type": "Chemical",
  "standard": "ISA"
}
```

**Response:** `201 Created`
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "My Process Plant",
  "description": "A chemical processing facility",
  "industry_type": "Chemical",
  "standard": "ISA",
  "status": "draft",
  "created_at": "2025-01-25T10:00:00Z",
  "updated_at": "2025-01-25T10:00:00Z",
  "owner_id": null,
  "project_data": {}
}
```

### List Projects

Get all projects with pagination.

**Endpoint:** `GET /projects`

**Query Parameters:**
- `skip` (integer, optional): Number of records to skip (default: 0)
- `limit` (integer, optional): Max records to return (default: 100)

**Response:** `200 OK`
```json
[
  {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "My Process Plant",
    ...
  },
  ...
]
```

### Get Project

Get a single project by ID.

**Endpoint:** `GET /projects/{project_id}`

**Response:** `200 OK` or `404 Not Found`

### Update Project

Update project details.

**Endpoint:** `PATCH /projects/{project_id}`

**Request Body:**
```json
{
  "name": "Updated Name",
  "status": "in_progress"
}
```

**Response:** `200 OK`

### Delete Project

Delete a project and all associated P&IDs.

**Endpoint:** `DELETE /projects/{project_id}`

**Response:** `204 No Content`

---

## P&IDs API

### Create P&ID

Create a new P&ID within a project.

**Endpoint:** `POST /pids`

**Request Body:**
```json
{
  "project_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Main Process",
  "description": "Primary process flow diagram"
}
```

**Response:** `201 Created`
```json
{
  "id": "660f9500-f39c-52e5-b827-557766551111",
  "project_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Main Process",
  "version": "1.0",
  "canvas_data": {},
  "generation_metadata": {},
  "created_at": "2025-01-25T10:05:00Z",
  "updated_at": "2025-01-25T10:05:00Z"
}
```

### List P&IDs

Get all P&IDs, optionally filtered by project.

**Endpoint:** `GET /pids`

**Query Parameters:**
- `project_id` (uuid, optional): Filter by project
- `skip` (integer, optional): Pagination offset
- `limit` (integer, optional): Max records

**Response:** `200 OK`

### Get P&ID

Get full P&ID with canvas data.

**Endpoint:** `GET /pids/{pid_id}`

**Response:** `200 OK`
```json
{
  "id": "660f9500-f39c-52e5-b827-557766551111",
  "project_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Main Process",
  "version": "1.0",
  "canvas_data": {
    "components": [...],
    "connections": [...]
  },
  ...
}
```

### Update P&ID

Update P&ID properties and canvas data.

**Endpoint:** `PATCH /pids/{pid_id}`

**Request Body:**
```json
{
  "canvas_data": {
    "components": [...],
    "connections": [...]
  }
}
```

**Response:** `200 OK`

---

## Components API

### Create Component

Add a component to a P&ID.

**Endpoint:** `POST /components`

**Request Body:**
```json
{
  "pid_id": "660f9500-f39c-52e5-b827-557766551111",
  "tag": "P-101",
  "category": "equipment",
  "component_type": "pump",
  "position_x": 100.0,
  "position_y": 150.0,
  "rotation": 0.0,
  "scale": 1.0,
  "properties": {
    "capacity": "100 m³/h",
    "head": "25 m",
    "power": "15 kW"
  }
}
```

**Response:** `201 Created`

### List Components

Get components for a P&ID.

**Endpoint:** `GET /components`

**Query Parameters:**
- `pid_id` (uuid, required): P&ID to filter by
- `category` (string, optional): Filter by category
- `skip`, `limit`: Pagination

**Response:** `200 OK`

### Get Component

Get detailed component information.

**Endpoint:** `GET /components/{component_id}`

**Response:** `200 OK`
```json
{
  "id": "770g0600-g40d-63f6-c938-668877662222",
  "pid_id": "660f9500-f39c-52e5-b827-557766551111",
  "tag": "P-101",
  "category": "equipment",
  "component_type": "pump",
  "position_x": 100.0,
  "position_y": 150.0,
  "rotation": 0.0,
  "scale": 1.0,
  "properties": {
    "capacity": "100 m³/h",
    "head": "25 m",
    "power": "15 kW",
    "material": "SS316"
  },
  "metadata": {},
  "notes": ["Spare pump available"],
  "documents": [],
  "created_at": "2025-01-25T10:10:00Z",
  "updated_at": "2025-01-25T10:15:00Z"
}
```

### Update Component

Update component properties or position.

**Endpoint:** `PATCH /components/{component_id}`

**Request Body:**
```json
{
  "position_x": 120.0,
  "properties": {
    "capacity": "120 m³/h"
  }
}
```

**Response:** `200 OK`

### Delete Component

Remove a component (also removes connected lines).

**Endpoint:** `DELETE /components/{component_id}`

**Response:** `204 No Content`

---

## Connections API

### Create Connection

Create a line between components.

**Endpoint:** `POST /components/connections`

**Request Body:**
```json
{
  "pid_id": "660f9500-f39c-52e5-b827-557766551111",
  "from_component_id": "770g0600-g40d-63f6-c938-668877662222",
  "to_component_id": "880h1700-h51e-74g7-d049-779988773333",
  "line_number": "LINE-101",
  "line_type": "process",
  "fluid_service": "Water",
  "line_size": "4\"",
  "piping_class": "150#",
  "material": "SS316",
  "path_data": {
    "points": [
      {"x": 150, "y": 150},
      {"x": 200, "y": 150}
    ]
  },
  "properties": {
    "design_pressure": "10 bar",
    "design_temp": "50 °C"
  }
}
```

**Response:** `201 Created`

### List Connections

Get all connections for a P&ID.

**Endpoint:** `GET /components/connections`

**Query Parameters:**
- `pid_id` (uuid, required): P&ID to filter by

**Response:** `200 OK`

### Update Connection

Modify connection properties.

**Endpoint:** `PATCH /components/connections/{connection_id}`

**Response:** `200 OK`

### Delete Connection

Remove a connection.

**Endpoint:** `DELETE /components/connections/{connection_id}`

**Response:** `204 No Content`

---

## Wizard API

### Extract Equipment

AI-powered equipment extraction from process description.

**Endpoint:** `POST /wizard/extract-equipment`

**Request Body:**
```json
{
  "process_description": "A mixing process with two feed pumps..."
}
```

**Response:** `200 OK`
```json
{
  "equipment": [
    {
      "tag": "P-101A/B",
      "type": "pump",
      "description": "Feed Pump",
      "properties": {
        "capacity": "100 m³/h"
      }
    },
    ...
  ]
}
```

### Get Suggestions

Get AI suggestions while user types.

**Endpoint:** `POST /wizard/suggestions`

**Request Body:**
```json
{
  "text": "The process includes heating..."
}
```

**Response:** `200 OK`
```json
{
  "suggestions": [
    "Consider adding temperature control",
    "Heat exchanger may be required",
    ...
  ]
}
```

### Validate Wizard Data

Validate complete wizard data before generation.

**Endpoint:** `POST /wizard/validate`

**Request Body:**
```json
{
  "project_info": {...},
  "process_description": {...},
  "equipment": [...],
  "piping": [...],
  "instrumentation": [...]
}
```

**Response:** `200 OK`
```json
{
  "valid": true,
  "errors": [],
  "warnings": ["No instrumentation specified"]
}
```

### Generate P&ID

Start asynchronous P&ID generation.

**Endpoint:** `POST /wizard/generate`

**Request Body:**
```json
{
  "project_id": "550e8400-e29b-41d4-a716-446655440000",
  "wizard_data": {
    "project_info": {...},
    "process_description": {...},
    "equipment": [...],
    "piping": [...],
    "instrumentation": [...]
  },
  "options": {}
}
```

**Response:** `202 Accepted`
```json
{
  "task_id": "990i2800-i62f-85h8-e150-880099884444",
  "status": "queued",
  "message": "P&ID generation started"
}
```

### Get Generation Status

Poll generation status.

**Endpoint:** `GET /wizard/generate/{task_id}`

**Response:** `200 OK`
```json
{
  "task_id": "990i2800-i62f-85h8-e150-880099884444",
  "status": "processing",
  "progress": 65,
  "current_step": "Optimizing layout",
  "pid_id": null,
  "error": null
}
```

**Status Values:**
- `queued`: Generation queued
- `processing`: AI agents working
- `completed`: Generation done (check `pid_id`)
- `failed`: Error occurred (check `error`)

**Progress:** 0-100 percentage

---

## WebSocket API

### Connect to P&ID

Real-time updates for collaborative editing.

**Endpoint:** `ws://localhost:8000/ws/{pid_id}`

**Client Messages:**
```json
{
  "type": "subscribe",
  "pid_id": "660f9500-f39c-52e5-b827-557766551111"
}
```

```json
{
  "type": "component_update",
  "pid_id": "660f9500-f39c-52e5-b827-557766551111",
  "component_id": "770g0600-g40d-63f6-c938-668877662222",
  "updates": {
    "position_x": 130.0
  }
}
```

**Server Messages:**
```json
{
  "type": "subscribed",
  "pid_id": "660f9500-f39c-52e5-b827-557766551111"
}
```

```json
{
  "type": "component_added",
  "pid_id": "660f9500-f39c-52e5-b827-557766551111",
  "component": {...}
}
```

```json
{
  "type": "generation_progress",
  "pid_id": "660f9500-f39c-52e5-b827-557766551111",
  "progress": 75,
  "status": "Finalizing..."
}
```

---

## Error Codes

| Code | Description |
|------|-------------|
| 200 | OK - Request successful |
| 201 | Created - Resource created |
| 204 | No Content - Deletion successful |
| 400 | Bad Request - Invalid input |
| 404 | Not Found - Resource not found |
| 422 | Validation Error - Input validation failed |
| 500 | Internal Server Error - Server error |

---

## Rate Limiting

Currently no rate limiting. Future versions will implement:
- 100 requests/minute for authenticated users
- 20 requests/minute for unauthenticated

---

## Pagination

All list endpoints support pagination:

**Query Parameters:**
- `skip`: Number of records to skip (default: 0)
- `limit`: Max records to return (default: 100, max: 1000)

**Response Headers:**
- `X-Total-Count`: Total number of records

---

## Examples

### Complete Workflow Example

```python
import requests

API_BASE = "http://localhost:8000/api/v1"

# 1. Create project
project = requests.post(f"{API_BASE}/projects", json={
    "name": "My Plant",
    "industry_type": "Chemical",
    "standard": "ISA"
}).json()

project_id = project["id"]

# 2. Generate P&ID via wizard
response = requests.post(f"{API_BASE}/wizard/generate", json={
    "project_id": project_id,
    "wizard_data": {
        "project_info": {...},
        "process_description": {...},
        "equipment": [...],
        ...
    }
})

task_id = response.json()["task_id"]

# 3. Poll for completion
import time
while True:
    status = requests.get(
        f"{API_BASE}/wizard/generate/{task_id}"
    ).json()

    print(f"Progress: {status['progress']}% - {status['current_step']}")

    if status["status"] == "completed":
        pid_id = status["pid_id"]
        break
    elif status["status"] == "failed":
        print(f"Error: {status['error']}")
        break

    time.sleep(2)

# 4. Get generated P&ID
pid = requests.get(f"{API_BASE}/pids/{pid_id}").json()
print(f"Generated P&ID: {pid['name']}")
print(f"Components: {len(pid['canvas_data']['components'])}")

# 5. Update component
component_id = pid['canvas_data']['components'][0]['id']
requests.patch(
    f"{API_BASE}/components/{component_id}",
    json={"properties": {"capacity": "150 m³/h"}}
)
```

### JavaScript/TypeScript Example

```typescript
const API_BASE = 'http://localhost:8000/api/v1'

// Create project
const project = await fetch(`${API_BASE}/projects`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'My Plant',
    industry_type: 'Chemical',
    standard: 'ISA'
  })
}).then(r => r.json())

// Generate P&ID
const { task_id } = await fetch(`${API_BASE}/wizard/generate`, {
  method: 'POST',
  body: JSON.stringify({
    project_id: project.id,
    wizard_data: { ... }
  })
}).then(r => r.json())

// Poll status
const checkStatus = async () => {
  const status = await fetch(
    `${API_BASE}/wizard/generate/${task_id}`
  ).then(r => r.json())

  console.log(`${status.progress}% - ${status.current_step}`)

  if (status.status === 'completed') {
    return status.pid_id
  }

  setTimeout(checkStatus, 2000)
}

const pid_id = await checkStatus()
```

---

## Interactive API Documentation

Visit **http://localhost:8000/docs** for interactive Swagger UI documentation where you can:
- Browse all endpoints
- View request/response schemas
- Try API calls directly in browser
- Download OpenAPI specification

---

## Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/p-id-symbols/issues)
- **Documentation**: [README](../README_NEW.md)
- **User Guide**: [USER_GUIDE.md](./USER_GUIDE.md)
