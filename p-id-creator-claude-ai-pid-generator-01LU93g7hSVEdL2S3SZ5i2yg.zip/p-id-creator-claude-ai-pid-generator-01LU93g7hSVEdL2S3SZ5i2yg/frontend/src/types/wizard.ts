/**
 * Wizard related types
 */
import { ProjectCreate } from './project'

export interface ProcessDescription {
  narrative: string
  operating_conditions?: Record<string, any>
  safety_requirements: string[]
}

export interface EquipmentSpec {
  tag: string
  type: string
  description: string
  properties: Record<string, any>
}

export interface PipingSpec {
  from_equipment: string
  to_equipment: string
  fluid_service: string
  line_size?: string
  material?: string
}

export interface InstrumentSpec {
  tag: string
  type: string
  measurement_type: string
  location: string
  properties: Record<string, any>
}

export interface WizardData {
  project_info: ProjectCreate
  process_description: ProcessDescription
  equipment: EquipmentSpec[]
  piping: PipingSpec[]
  instrumentation: InstrumentSpec[]
}

export interface GenerationStatus {
  task_id: string
  status: 'queued' | 'processing' | 'completed' | 'failed'
  progress: number
  current_step: string
  pid_id?: string
  error?: string
}
