/**
 * Project related types
 */

export enum IndustryType {
  OIL_GAS = "Oil & Gas",
  PETROCHEMICAL = "Petrochemical",
  CHEMICAL = "Chemical",
  PHARMACEUTICAL = "Pharmaceutical",
  WATER_TREATMENT = "Water Treatment",
  POWER_GENERATION = "Power Generation",
  FOOD_BEVERAGE = "Food & Beverage",
  OTHER = "Other"
}

export enum StandardType {
  ISA = "ISA",
  ISO = "ISO",
  ANSI = "ANSI",
  DIN = "DIN"
}

export enum ProjectStatus {
  DRAFT = "draft",
  IN_PROGRESS = "in_progress",
  REVIEW = "review",
  COMPLETED = "completed",
  ARCHIVED = "archived"
}

export interface Project {
  id: string
  name: string
  description?: string
  industry_type: IndustryType
  standard: StandardType
  status: ProjectStatus
  created_at: string
  updated_at: string
  owner_id?: string
  project_data: Record<string, any>
}

export interface ProjectCreate {
  name: string
  description?: string
  industry_type: IndustryType
  standard: StandardType
}
