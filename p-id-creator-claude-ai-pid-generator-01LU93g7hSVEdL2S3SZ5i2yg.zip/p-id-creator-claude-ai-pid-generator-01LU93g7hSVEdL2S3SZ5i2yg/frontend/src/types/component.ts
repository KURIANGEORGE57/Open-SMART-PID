/**
 * Component types for canvas
 */

export enum ComponentCategory {
  EQUIPMENT = "equipment",
  VALVE = "valve",
  INSTRUMENT = "instrument",
  LINE = "line",
  FITTING = "fitting",
  ANNOTATION = "annotation"
}

export enum ComponentType {
  // Equipment
  TANK = "tank",
  REACTOR = "reactor",
  COLUMN = "column",
  SEPARATOR = "separator",
  PUMP = "pump",
  COMPRESSOR = "compressor",
  HEAT_EXCHANGER = "heat_exchanger",
  FILTER = "filter",
  MIXER = "mixer",

  // Valves (from YOLOv5)
  GATE_VALVE = "gate_valve",
  BALL_VALVE = "ball_valve",
  GLOBE_VALVE = "globe_valve",
  BUTTERFLY_VALVE = "butterfly_valve",
  CHECK_VALVE = "check_valve",
  CONTROL_VALVE = "control_valve",
  PLUG_VALVE = "plug_valve",

  // Instruments
  PRESSURE_INDICATOR = "pressure_indicator",
  TEMPERATURE_INDICATOR = "temperature_indicator",
  FLOW_INDICATOR = "flow_indicator",
  LEVEL_INDICATOR = "level_indicator",
}

export interface Position {
  x: number
  y: number
}

export interface CanvasComponent {
  id: string
  tag: string
  category: ComponentCategory
  component_type: ComponentType
  position: Position
  rotation: number
  scale: number
  properties: Record<string, any>
  metadata?: Record<string, any>
  notes?: string[]
  documents?: any[]
}

export interface Connection {
  id: string
  from_component_id: string
  to_component_id: string
  line_number?: string
  line_type: 'process' | 'utility' | 'instrument' | 'signal'
  fluid_service?: string
  line_size?: string
  path: Position[]
  properties: Record<string, any>
}

export interface CanvasState {
  components: CanvasComponent[]
  connections: Connection[]
  selectedId: string | null
  zoom: number
  pan: Position
}
