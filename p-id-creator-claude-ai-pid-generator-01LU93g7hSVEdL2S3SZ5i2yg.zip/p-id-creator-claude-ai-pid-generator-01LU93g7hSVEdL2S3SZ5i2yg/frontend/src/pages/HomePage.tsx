import { Link } from 'react-router-dom'

export default function HomePage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h1 className="text-6xl font-bold text-gray-900 mb-6">
          Smart P&ID Creator
        </h1>
        <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
          AI-powered Piping and Instrumentation Diagram generation system.
          Create interactive, data-rich engineering diagrams from natural language instructions.
        </p>

        <div className="flex gap-4 justify-center">
          <Link
            to="/wizard"
            className="px-8 py-4 bg-blue-600 text-white rounded-lg font-semibold text-lg hover:bg-blue-700 transition-colors shadow-lg"
          >
            Create New P&ID
          </Link>
          <Link
            to="/projects"
            className="px-8 py-4 bg-white text-blue-600 border-2 border-blue-600 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-colors"
          >
            View Projects
          </Link>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard
            title="AI-Powered Generation"
            description="Describe your process in plain English and let AI generate the P&ID"
            icon="🤖"
          />
          <FeatureCard
            title="Interactive Components"
            description="Click any component to view and edit detailed properties"
            icon="🔍"
          />
          <FeatureCard
            title="Professional Exports"
            description="Export to PDF, SVG, DXF, and generate equipment lists"
            icon="📄"
          />
        </div>

        <div className="mt-12 text-sm text-gray-500">
          <p>Open Source • Built with React, FastAPI, and LangGraph</p>
        </div>
      </div>
    </div>
  )
}

function FeatureCard({ title, description, icon }: { title: string; description: string; icon: string }) {
  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}
