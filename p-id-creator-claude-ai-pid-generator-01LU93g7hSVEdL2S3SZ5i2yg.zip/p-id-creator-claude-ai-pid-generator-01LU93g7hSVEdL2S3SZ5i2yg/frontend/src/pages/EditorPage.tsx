import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { PIDCanvas } from '../components/Canvas/PIDCanvas'
import { ComponentInspector } from '../components/Inspector/ComponentInspector'
import { useCanvasStore } from '../stores/canvasStore'

export default function EditorPage() {
  const { pidId } = useParams()
  const navigate = useNavigate()
  const { loadCanvas, exportCanvas, clearCanvas } = useCanvasStore()
  const [pidName, setPidName] = useState('Untitled P&ID')
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    // Load P&ID data
    // TODO: Fetch from API
    if (pidId) {
      // Mock data for now
      loadMockData()
    }
  }, [pidId])

  const loadMockData = () => {
    // Load example P&ID
    loadCanvas({
      components: [
        {
          id: '1',
          tag: 'T-101',
          category: 'equipment' as any,
          component_type: 'tank' as any,
          position: { x: 100, y: 100 },
          rotation: 0,
          scale: 1,
          properties: {
            volume: '50 m³',
            material: 'SS316',
            design_pressure: 'Atmospheric'
          }
        },
        {
          id: '2',
          tag: 'P-101A',
          category: 'equipment' as any,
          component_type: 'pump' as any,
          position: { x: 300, y: 150 },
          rotation: 0,
          scale: 1,
          properties: {
            capacity: '100 m³/h',
            head: '25 m',
            power: '15 kW'
          }
        },
        {
          id: '3',
          tag: 'E-101',
          category: 'equipment' as any,
          component_type: 'heat_exchanger' as any,
          position: { x: 500, y: 150 },
          rotation: 0,
          scale: 1,
          properties: {
            duty: '500 kW',
            area: '25 m²'
          }
        },
      ],
      connections: [
        {
          id: 'c1',
          from_component_id: '1',
          to_component_id: '2',
          line_number: 'LINE-101',
          line_type: 'process' as any,
          fluid_service: 'Water',
          line_size: '4"',
          path: [
            { x: 160, y: 140 },
            { x: 230, y: 140 },
            { x: 230, y: 175 },
            { x: 300, y: 175 }
          ],
          properties: {}
        },
        {
          id: 'c2',
          from_component_id: '2',
          to_component_id: '3',
          line_number: 'LINE-102',
          line_type: 'process' as any,
          fluid_service: 'Water',
          line_size: '4"',
          path: [
            { x: 350, y: 175 },
            { x: 425, y: 175 },
            { x: 425, y: 180 },
            { x: 500, y: 180 }
          ],
          properties: {}
        }
      ]
    })
    setPidName('Example Process')
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      const canvasData = exportCanvas()
      // TODO: Save to API
      console.log('Saving P&ID:', canvasData)
      alert('P&ID saved successfully!')
    } catch (error) {
      console.error('Failed to save:', error)
      alert('Failed to save P&ID')
    } finally {
      setIsSaving(false)
    }
  }

  const handleExport = () => {
    const canvasData = exportCanvas()
    const dataStr = JSON.stringify(canvasData, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${pidName}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      {/* Header */}
      <header className="bg-gray-800 shadow-lg border-b border-gray-700">
        <div className="px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/projects')}
              className="text-gray-400 hover:text-white"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
            </button>
            <h1 className="text-xl font-bold">{pidName}</h1>
            <span className="text-sm text-gray-400">• P&ID Editor</span>
          </div>

          <div className="flex gap-2">
            <button className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm">
              Undo
            </button>
            <button className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm">
              Redo
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm disabled:bg-gray-700"
            >
              {isSaving ? 'Saving...' : 'Save'}
            </button>
            <button
              onClick={handleExport}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-sm"
            >
              Export
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Canvas */}
        <div className="flex-1">
          <PIDCanvas />
        </div>

        {/* Inspector Panel */}
        <ComponentInspector />
      </main>

      {/* Toolbar (Optional - for adding components) */}
      <div className="hidden">
        {/* Component palette can go here */}
      </div>
    </div>
  )
}
