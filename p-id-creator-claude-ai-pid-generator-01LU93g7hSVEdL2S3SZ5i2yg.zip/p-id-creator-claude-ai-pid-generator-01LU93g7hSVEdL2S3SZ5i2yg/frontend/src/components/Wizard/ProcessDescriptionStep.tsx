/**
 * Step 2: Process Description
 */
import { useState, useCallback } from 'react'
import { useWizardStore } from '../../stores/wizardStore'
import { wizardService } from '../../services/wizardService'

export default function ProcessDescriptionStep() {
  const { processDescription, setProcessDescription } = useWizardStore()
  const [narrative, setNarrative] = useState(processDescription?.narrative || '')
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false)

  const handleSave = () => {
    setProcessDescription({
      narrative,
      safety_requirements: []
    })
  }

  // Debounced suggestions (simplified - would use actual debounce in production)
  const loadSuggestions = useCallback(async (text: string) => {
    if (text.length < 20) return

    setIsLoadingSuggestions(true)
    try {
      const sugg = await wizardService.getSuggestions(text)
      setSuggestions(sugg)
    } catch (error) {
      console.error('Failed to load suggestions:', error)
    } finally {
      setIsLoadingSuggestions(false)
    }
  }, [])

  const handleTextChange = (text: string) => {
    setNarrative(text)
    // In production, debounce this
    // loadSuggestions(text)
  }

  const applyTemplate = (template: string) => {
    let templateText = ''

    switch (template) {
      case 'mixing':
        templateText = `A simple mixing process with two feed streams.

Raw material is stored in Tank T-101 and pumped using Pump P-101A/B to the mixing vessel V-101.
A second feed stream from Tank T-102 is also pumped via Pump P-102 into the mixer.

The mixer is equipped with an agitator and temperature control. The mixed product flows by gravity to storage tank T-103.

Flow, temperature, and level measurements are required throughout the process.`
        break

      case 'distillation':
        templateText = `A batch distillation process.

Feed from Tank T-101 is heated in Heat Exchanger E-101 and fed to Distillation Column C-101.
The column operates under partial vacuum created by Vacuum Pump P-101.

Overhead vapor is condensed in Condenser E-102 and collected in Receiver V-101.
Bottom product is cooled in Cooler E-103 and sent to storage Tank T-102.

Temperature, pressure, and level controls are essential for safe operation.`
        break

      case 'cooling':
        templateText = `A cooling water circulation system.

Cooling water is supplied from Cooling Tower CT-101 and circulated by Pump P-101A/B.
The water flows through multiple heat exchangers (E-101, E-102, E-103) where it absorbs heat from process streams.

Warm water returns to the cooling tower for heat rejection.
A makeup water line compensates for evaporation losses.

Flow and temperature monitoring ensures efficient heat transfer.`
        break
    }

    setNarrative(templateText)
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Process Description</h2>

      <div className="space-y-6">
        {/* Template Gallery */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3">
            Start from a template (optional)
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {[
              { id: 'mixing', name: 'Mixing Process', icon: '🔄' },
              { id: 'distillation', name: 'Distillation', icon: '🏭' },
              { id: 'cooling', name: 'Cooling Water', icon: '❄️' },
            ].map((template) => (
              <button
                key={template.id}
                onClick={() => applyTemplate(template.id)}
                className="p-4 border-2 border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors text-center"
              >
                <div className="text-3xl mb-2">{template.icon}</div>
                <div className="text-sm font-medium">{template.name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Text Area */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Describe your process in plain English *
          </label>
          <textarea
            value={narrative}
            onChange={(e) => handleTextChange(e.target.value)}
            rows={12}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
            placeholder="Example: A chemical mixing process where two feed streams are combined in a stirred tank. Stream A from Tank-101 is pumped using Pump-101A/B to the mixer. Stream B from Tank-102 is also pumped to the mixer. The mixed product is then cooled and sent to storage..."
          />
          <p className="mt-2 text-sm text-gray-500">
            {narrative.length} characters
          </p>
        </div>

        {/* AI Suggestions */}
        {suggestions.length > 0 && (
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h3 className="font-semibold text-purple-900 mb-2">🤖 AI Suggestions</h3>
            <ul className="space-y-2">
              {suggestions.map((suggestion, index) => (
                <li key={index} className="text-sm text-purple-800">
                  • {suggestion}
                </li>
              ))}
            </ul>
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={narrative.length < 20}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          Save & Continue
        </button>
      </div>

      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-semibold text-blue-900 mb-2">💡 Tips for a good description</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Mention all major equipment (tanks, pumps, reactors, etc.)</li>
          <li>• Describe the flow sequence from beginning to end</li>
          <li>• Include fluid types and process conditions</li>
          <li>• Note any critical control or safety requirements</li>
        </ul>
      </div>
    </div>
  )
}
