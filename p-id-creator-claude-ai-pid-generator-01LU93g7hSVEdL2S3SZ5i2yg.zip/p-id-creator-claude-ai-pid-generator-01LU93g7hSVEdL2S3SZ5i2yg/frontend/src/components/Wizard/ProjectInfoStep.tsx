/**
 * Step 1: Project Information
 */
import { useForm } from 'react-hook-form'
import { useWizardStore } from '../../stores/wizardStore'
import { ProjectCreate, IndustryType, StandardType } from '../../types/project'
import { useEffect } from 'react'

export default function ProjectInfoStep() {
  const { projectInfo, setProjectInfo } = useWizardStore()

  const { register, handleSubmit, formState: { errors } } = useForm<ProjectCreate>({
    defaultValues: projectInfo || {
      name: '',
      description: '',
      industry_type: IndustryType.CHEMICAL,
      standard: StandardType.ISA
    }
  })

  const onSubmit = (data: ProjectCreate) => {
    setProjectInfo(data)
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Project Information</h2>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Project Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Project Name *
          </label>
          <input
            type="text"
            {...register('name', { required: 'Project name is required' })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter project name"
          />
          {errors.name && (
            <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <textarea
            {...register('description')}
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Optional project description"
          />
        </div>

        {/* Industry Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Industry Type *
          </label>
          <select
            {...register('industry_type', { required: 'Industry type is required' })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {Object.values(IndustryType).map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
          {errors.industry_type && (
            <p className="mt-1 text-sm text-red-600">{errors.industry_type.message}</p>
          )}
        </div>

        {/* Standard */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            P&ID Standard *
          </label>
          <select
            {...register('standard', { required: 'Standard is required' })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {Object.values(StandardType).map((std) => (
              <option key={std} value={std}>
                {std === StandardType.ISA ? 'ISA S5.1' : std}
              </option>
            ))}
          </select>
          {errors.standard && (
            <p className="mt-1 text-sm text-red-600">{errors.standard.message}</p>
          )}
        </div>

        <button
          type="submit"
          className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
        >
          Save & Continue
        </button>
      </form>

      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-semibold text-blue-900 mb-2">💡 Tip</h3>
        <p className="text-sm text-blue-800">
          Choose the appropriate standard for your region and industry. ISA S5.1 is widely used
          in North America, while ISO 10628 is common in Europe.
        </p>
      </div>
    </div>
  )
}
