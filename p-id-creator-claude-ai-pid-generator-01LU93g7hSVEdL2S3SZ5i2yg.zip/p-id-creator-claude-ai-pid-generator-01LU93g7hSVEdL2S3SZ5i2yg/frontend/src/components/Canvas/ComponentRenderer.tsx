/**
 * Component renderer for canvas
 */
import React from 'react'
import { Group, Text, Rect } from 'react-konva'
import { CanvasComponent } from '../../types/component'
import { getSymbolComponent } from './SymbolLibrary'

interface ComponentRendererProps {
  component: CanvasComponent
  isSelected: boolean
  onSelect: () => void
  onDragEnd: (e: any) => void
}

export const ComponentRenderer: React.FC<ComponentRendererProps> = ({
  component,
  isSelected,
  onSelect,
  onDragEnd
}) => {
  const SymbolComponent = getSymbolComponent(component.component_type)

  return (
    <Group
      x={component.position.x}
      y={component.position.y}
      draggable
      onDragEnd={onDragEnd}
      onClick={onSelect}
      onTap={onSelect}
    >
      {/* Selection indicator */}
      {isSelected && (
        <Rect
          x={-5}
          y={-5}
          width={70}
          height={90}
          stroke="#3b82f6"
          strokeWidth={2}
          dash={[5, 5]}
          listening={false}
        />
      )}

      {/* Symbol */}
      <SymbolComponent
        scale={component.scale}
        rotation={component.rotation}
        stroke={isSelected ? '#3b82f6' : '#000'}
      />

      {/* Tag label */}
      <Text
        text={component.tag}
        x={-10}
        y={95}
        fontSize={12}
        fontFamily="Arial"
        fontStyle="bold"
        fill="#000"
        listening={false}
      />
    </Group>
  )
}
