/**
 * Grid Layer for canvas background
 */
import React from 'react'
import { Group, Line } from 'react-konva'

interface GridLayerProps {
  width: number
  height: number
  gridSize: number
}

export const GridLayer: React.FC<GridLayerProps> = ({
  width,
  height,
  gridSize
}) => {
  const lines: JSX.Element[] = []

  // Vertical lines
  for (let i = 0; i < width / gridSize; i++) {
    lines.push(
      <Line
        key={`v-${i}`}
        points={[i * gridSize, 0, i * gridSize, height]}
        stroke="#e5e7eb"
        strokeWidth={1}
      />
    )
  }

  // Horizontal lines
  for (let i = 0; i < height / gridSize; i++) {
    lines.push(
      <Line
        key={`h-${i}`}
        points={[0, i * gridSize, width, i * gridSize]}
        stroke="#e5e7eb"
        strokeWidth={1}
      />
    )
  }

  // Major grid lines every 100px
  for (let i = 0; i < width / 100; i++) {
    lines.push(
      <Line
        key={`v-major-${i}`}
        points={[i * 100, 0, i * 100, height]}
        stroke="#d1d5db"
        strokeWidth={1}
      />
    )
  }

  for (let i = 0; i < height / 100; i++) {
    lines.push(
      <Line
        key={`h-major-${i}`}
        points={[0, i * 100, width, i * 100]}
        stroke="#d1d5db"
        strokeWidth={1}
      />
    )
  }

  return <Group>{lines}</Group>
}
