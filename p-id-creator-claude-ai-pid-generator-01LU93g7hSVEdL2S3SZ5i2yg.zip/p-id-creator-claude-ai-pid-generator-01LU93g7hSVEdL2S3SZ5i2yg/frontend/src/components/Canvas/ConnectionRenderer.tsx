/**
 * Connection line renderer
 */
import React from 'react'
import { Group, Line, Text, Circle } from 'react-konva'
import { Connection, Position } from '../../types/component'

interface ConnectionRendererProps {
  connection: Connection
  isSelected: boolean
  onSelect: () => void
}

export const ConnectionRenderer: React.FC<ConnectionRendererProps> = ({
  connection,
  isSelected,
  onSelect
}) => {
  // Flatten path points for Konva Line component
  const points = connection.path.flatMap(p => [p.x, p.y])

  // Calculate midpoint for label
  const midIndex = Math.floor(connection.path.length / 2)
  const midPoint = connection.path[midIndex] || connection.path[0]

  // Line style based on type
  const getLineStyle = () => {
    switch (connection.line_type) {
      case 'utility':
        return { stroke: '#16a34a', dash: [10, 5] }
      case 'instrument':
        return { stroke: '#dc2626', dash: [5, 5] }
      case 'signal':
        return { stroke: '#9333ea', dash: [2, 2] }
      default:
        return { stroke: '#000', dash: [] }
    }
  }

  const lineStyle = getLineStyle()

  return (
    <Group onClick={onSelect} onTap={onSelect}>
      {/* Main line */}
      <Line
        points={points}
        stroke={isSelected ? '#3b82f6' : lineStyle.stroke}
        strokeWidth={isSelected ? 3 : 2}
        dash={lineStyle.dash}
        lineCap="round"
        lineJoin="round"
      />

      {/* Flow direction arrow */}
      {connection.path.length >= 2 && (
        <Group>
          {connection.path.slice(1).map((point, index) => {
            const prevPoint = connection.path[index]
            const angle = Math.atan2(
              point.y - prevPoint.y,
              point.x - prevPoint.x
            ) * 180 / Math.PI

            // Draw arrow at midpoint of each segment
            const midX = (prevPoint.x + point.x) / 2
            const midY = (prevPoint.y + point.y) / 2

            return (
              <Group
                key={index}
                x={midX}
                y={midY}
                rotation={angle}
              >
                <Line
                  points={[-5, -5, 0, 0, -5, 5]}
                  stroke={lineStyle.stroke}
                  strokeWidth={2}
                  lineCap="round"
                  lineJoin="round"
                  listening={false}
                />
              </Group>
            )
          })}
        </Group>
      )}

      {/* Line number label */}
      {connection.line_number && midPoint && (
        <Group x={midPoint.x} y={midPoint.y - 15}>
          <Rect
            x={-25}
            y={-8}
            width={50}
            height={16}
            fill="#fff"
            stroke={lineStyle.stroke}
            strokeWidth={1}
            cornerRadius={3}
            listening={false}
          />
          <Text
            text={connection.line_number}
            x={-23}
            y={-5}
            width={46}
            align="center"
            fontSize={10}
            fontFamily="Arial"
            fill={lineStyle.stroke}
            listening={false}
          />
        </Group>
      )}

      {/* Connection points (for debugging/editing) */}
      {isSelected && connection.path.map((point, index) => (
        <Circle
          key={index}
          x={point.x}
          y={point.y}
          radius={4}
          fill="#3b82f6"
          listening={false}
        />
      ))}
    </Group>
  )
}
