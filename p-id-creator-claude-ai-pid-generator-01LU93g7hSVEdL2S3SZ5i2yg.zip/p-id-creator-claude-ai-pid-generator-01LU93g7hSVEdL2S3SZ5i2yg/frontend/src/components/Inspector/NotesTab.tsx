/**
 * Notes Tab - Component notes and documentation
 */
import React, { useState } from 'react'
import { CanvasComponent } from '../../types/component'
import { useCanvasStore } from '../../stores/canvasStore'

interface NotesTabProps {
  component: CanvasComponent
}

export const NotesTab: React.FC<NotesTabProps> = ({ component }) => {
  const { updateComponent } = useCanvasStore()
  const [newNote, setNewNote] = useState('')

  const notes = component.notes || []

  const handleAddNote = () => {
    if (!newNote.trim()) return

    const updatedNotes = [...notes, newNote]
    updateComponent(component.id, { notes: updatedNotes })
    setNewNote('')
  }

  const handleDeleteNote = (index: number) => {
    const updatedNotes = notes.filter((_, i) => i !== index)
    updateComponent(component.id, { notes: updatedNotes })
  }

  return (
    <div className="p-4 space-y-4">
      {/* Add Note */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Add Note
        </label>
        <textarea
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="Enter note..."
        />
        <button
          onClick={handleAddNote}
          disabled={!newNote.trim()}
          className="mt-2 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          Add Note
        </button>
      </div>

      {/* Notes List */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-2">
          Notes ({notes.length})
        </h3>
        {notes.length === 0 ? (
          <p className="text-sm text-gray-500">No notes yet</p>
        ) : (
          <div className="space-y-2">
            {notes.map((note, index) => (
              <div
                key={index}
                className="p-3 border border-gray-200 rounded-lg bg-yellow-50"
              >
                <div className="flex justify-between items-start">
                  <p className="text-sm text-gray-700 flex-1">{note}</p>
                  <button
                    onClick={() => handleDeleteNote(index)}
                    className="ml-2 text-gray-400 hover:text-red-600"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Documents Section */}
      <div className="border-t border-gray-200 pt-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-2">
          Documents
        </h3>
        <p className="text-sm text-gray-500 mb-2">Attach datasheets, manuals, etc.</p>
        <button className="w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-800">
          + Upload Document
        </button>
      </div>
    </div>
  )
}
