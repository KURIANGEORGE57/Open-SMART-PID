/**
 * Properties Tab - Dynamic property forms
 */
import React, { useState } from 'react'
import { CanvasComponent } from '../../types/component'
import { useCanvasStore } from '../../stores/canvasStore'

interface PropertiesTabProps {
  component: CanvasComponent
}

export const PropertiesTab: React.FC<PropertiesTabProps> = ({ component }) => {
  const { updateComponent } = useCanvasStore()
  const [editedProps, setEditedProps] = useState(component.properties)

  const handlePropertyChange = (key: string, value: any) => {
    const newProps = { ...editedProps, [key]: value }
    setEditedProps(newProps)
    updateComponent(component.id, { properties: newProps })
  }

  const handleTagChange = (newTag: string) => {
    updateComponent(component.id, { tag: newTag })
  }

  // Get property schema based on component type
  const getPropertyFields = () => {
    const type = component.component_type

    if (type === 'pump') {
      return [
        { key: 'capacity', label: 'Capacity', type: 'text', unit: 'm³/h' },
        { key: 'head', label: 'Head', type: 'text', unit: 'm' },
        { key: 'power', label: 'Power', type: 'text', unit: 'kW' },
        { key: 'efficiency', label: 'Efficiency', type: 'text', unit: '%' },
        { key: 'npsh_required', label: 'NPSH Required', type: 'text', unit: 'm' },
        { key: 'material', label: 'Material', type: 'text' },
        { key: 'seal_type', label: 'Seal Type', type: 'text' },
        { key: 'driver', label: 'Driver', type: 'text' },
        { key: 'spared', label: 'Spared', type: 'checkbox' },
      ]
    }

    if (type === 'tank') {
      return [
        { key: 'volume', label: 'Volume', type: 'text', unit: 'm³' },
        { key: 'diameter', label: 'Diameter', type: 'text', unit: 'm' },
        { key: 'height', label: 'Height', type: 'text', unit: 'm' },
        { key: 'design_pressure', label: 'Design Pressure', type: 'text', unit: 'bar' },
        { key: 'design_temp', label: 'Design Temperature', type: 'text', unit: '°C' },
        { key: 'material', label: 'Material', type: 'text' },
        { key: 'insulation', label: 'Insulation', type: 'text' },
      ]
    }

    if (type === 'heat_exchanger') {
      return [
        { key: 'duty', label: 'Duty', type: 'text', unit: 'kW' },
        { key: 'area', label: 'Heat Transfer Area', type: 'text', unit: 'm²' },
        { key: 'shell_material', label: 'Shell Material', type: 'text' },
        { key: 'tube_material', label: 'Tube Material', type: 'text' },
        { key: 'shell_pressure', label: 'Shell Design Pressure', type: 'text', unit: 'bar' },
        { key: 'tube_pressure', label: 'Tube Design Pressure', type: 'text', unit: 'bar' },
      ]
    }

    // Default fields for other types
    return [
      { key: 'description', label: 'Description', type: 'text' },
      { key: 'manufacturer', label: 'Manufacturer', type: 'text' },
      { key: 'model', label: 'Model', type: 'text' },
      { key: 'material', label: 'Material', type: 'text' },
    ]
  }

  const propertyFields = getPropertyFields()

  return (
    <div className="p-4 space-y-4">
      {/* Basic Info */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Tag Number
        </label>
        <input
          type="text"
          value={component.tag}
          onChange={(e) => handleTagChange(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Type
        </label>
        <input
          type="text"
          value={component.component_type.replace('_', ' ')}
          disabled
          className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
        />
      </div>

      <div className="border-t border-gray-200 pt-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Properties</h3>

        {propertyFields.map(field => (
          <div key={field.key} className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {field.label}
              {field.unit && <span className="text-gray-500 ml-1">({field.unit})</span>}
            </label>

            {field.type === 'checkbox' ? (
              <input
                type="checkbox"
                checked={editedProps[field.key] || false}
                onChange={(e) => handlePropertyChange(field.key, e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
            ) : field.type === 'textarea' ? (
              <textarea
                value={editedProps[field.key] || ''}
                onChange={(e) => handlePropertyChange(field.key, e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            ) : (
              <input
                type="text"
                value={editedProps[field.key] || ''}
                onChange={(e) => handlePropertyChange(field.key, e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder={`Enter ${field.label.toLowerCase()}`}
              />
            )}
          </div>
        ))}
      </div>

      {/* Position Info */}
      <div className="border-t border-gray-200 pt-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Position</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-gray-600 mb-1">X</label>
            <input
              type="number"
              value={Math.round(component.position.x)}
              onChange={(e) => updateComponent(component.id, {
                position: { ...component.position, x: Number(e.target.value) }
              })}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-600 mb-1">Y</label>
            <input
              type="number"
              value={Math.round(component.position.y)}
              onChange={(e) => updateComponent(component.id, {
                position: { ...component.position, y: Number(e.target.value) }
              })}
              className="w-full px-2 py-1 text-sm border border-gray-300 rounded"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
