/**
 * Wizard service - API calls for P&ID generation wizard
 */
import api from './api'
import { WizardData, EquipmentSpec, GenerationStatus } from '../types/wizard'

export const wizardService = {
  // Extract equipment from process description
  async extractEquipment(processDescription: string): Promise<EquipmentSpec[]> {
    const response = await api.post('/wizard/extract-equipment', {
      process_description: processDescription
    })
    return response.data.equipment
  },

  // Get AI suggestions
  async getSuggestions(text: string): Promise<string[]> {
    const response = await api.post('/wizard/suggestions', { text })
    return response.data.suggestions
  },

  // Validate wizard data
  async validate(wizardData: WizardData): Promise<{
    valid: boolean
    errors: string[]
    warnings: string[]
  }> {
    const response = await api.post('/wizard/validate', wizardData)
    return response.data
  },

  // Generate P&ID
  async generate(projectId: string, wizardData: WizardData): Promise<{
    task_id: string
    status: string
    message: string
  }> {
    const response = await api.post('/wizard/generate', {
      project_id: projectId,
      wizard_data: wizardData,
      options: {}
    })
    return response.data
  },

  // Get generation status
  async getStatus(taskId: string): Promise<GenerationStatus> {
    const response = await api.get(`/wizard/generate/${taskId}`)
    return response.data
  }
}
