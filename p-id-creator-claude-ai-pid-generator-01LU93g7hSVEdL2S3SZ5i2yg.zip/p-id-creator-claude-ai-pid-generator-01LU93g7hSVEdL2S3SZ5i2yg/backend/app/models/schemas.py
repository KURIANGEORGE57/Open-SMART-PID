"""
Pydantic schemas for API requests and responses
"""
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID

from app.models.project import IndustryType, StandardType, ProjectStatus
from app.models.component import ComponentCategory, ComponentType, LineType


# ============================================================================
# Project Schemas
# ============================================================================

class ProjectBase(BaseModel):
    """Base project schema"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    industry_type: IndustryType
    standard: StandardType


class ProjectCreate(ProjectBase):
    """Schema for creating a project"""
    pass


class ProjectUpdate(BaseModel):
    """Schema for updating a project"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    industry_type: Optional[IndustryType] = None
    standard: Optional[StandardType] = None
    status: Optional[ProjectStatus] = None


class ProjectResponse(ProjectBase):
    """Schema for project response"""
    id: UUID
    status: ProjectStatus
    created_at: datetime
    updated_at: datetime
    owner_id: Optional[UUID] = None
    project_data: Dict[str, Any] = {}

    model_config = ConfigDict(from_attributes=True)


# ============================================================================
# PID Schemas
# ============================================================================

class PIDBase(BaseModel):
    """Base PID schema"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None


class PIDCreate(PIDBase):
    """Schema for creating a PID"""
    project_id: UUID


class PIDUpdate(BaseModel):
    """Schema for updating a PID"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    canvas_data: Optional[Dict[str, Any]] = None


class PIDResponse(PIDBase):
    """Schema for PID response"""
    id: UUID
    project_id: UUID
    version: str
    canvas_data: Dict[str, Any] = {}
    generation_metadata: Dict[str, Any] = {}
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================================================
# Component Schemas
# ============================================================================

class ComponentBase(BaseModel):
    """Base component schema"""
    tag: str = Field(..., min_length=1, max_length=100)
    category: ComponentCategory
    component_type: ComponentType
    position_x: float
    position_y: float
    rotation: float = 0.0
    scale: float = 1.0
    properties: Dict[str, Any] = {}


class ComponentCreate(ComponentBase):
    """Schema for creating a component"""
    pid_id: UUID


class ComponentUpdate(BaseModel):
    """Schema for updating a component"""
    tag: Optional[str] = Field(None, min_length=1, max_length=100)
    position_x: Optional[float] = None
    position_y: Optional[float] = None
    rotation: Optional[float] = None
    scale: Optional[float] = None
    properties: Optional[Dict[str, Any]] = None
    notes: Optional[List[str]] = None


class ComponentResponse(ComponentBase):
    """Schema for component response"""
    id: UUID
    pid_id: UUID
    symbol_type: Optional[str] = None
    metadata: Dict[str, Any] = {}
    notes: List[str] = []
    documents: List[Dict[str, Any]] = []
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================================================
# Connection Schemas
# ============================================================================

class ConnectionBase(BaseModel):
    """Base connection schema"""
    line_number: Optional[str] = Field(None, max_length=100)
    line_type: LineType = LineType.PROCESS
    fluid_service: Optional[str] = None
    line_size: Optional[str] = None
    piping_class: Optional[str] = None
    material: Optional[str] = None
    path_data: Dict[str, Any] = {}
    properties: Dict[str, Any] = {}


class ConnectionCreate(ConnectionBase):
    """Schema for creating a connection"""
    pid_id: UUID
    from_component_id: Optional[UUID] = None
    to_component_id: Optional[UUID] = None


class ConnectionUpdate(BaseModel):
    """Schema for updating a connection"""
    line_number: Optional[str] = None
    line_type: Optional[LineType] = None
    fluid_service: Optional[str] = None
    line_size: Optional[str] = None
    piping_class: Optional[str] = None
    material: Optional[str] = None
    path_data: Optional[Dict[str, Any]] = None
    properties: Optional[Dict[str, Any]] = None


class ConnectionResponse(ConnectionBase):
    """Schema for connection response"""
    id: UUID
    pid_id: UUID
    from_component_id: Optional[UUID] = None
    to_component_id: Optional[UUID] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================================================
# Wizard Schemas
# ============================================================================

class ProcessDescription(BaseModel):
    """Process description from wizard"""
    narrative: str
    operating_conditions: Optional[Dict[str, Any]] = {}
    safety_requirements: List[str] = []


class EquipmentSpec(BaseModel):
    """Equipment specification"""
    tag: str
    type: str
    description: str
    properties: Dict[str, Any] = {}


class PipingSpec(BaseModel):
    """Piping specification"""
    from_equipment: str
    to_equipment: str
    fluid_service: str
    line_size: Optional[str] = None
    material: Optional[str] = None


class InstrumentSpec(BaseModel):
    """Instrument specification"""
    tag: str
    type: str
    measurement_type: str
    location: str
    properties: Dict[str, Any] = {}


class WizardData(BaseModel):
    """Complete wizard data for P&ID generation"""
    project_info: ProjectCreate
    process_description: ProcessDescription
    equipment: List[EquipmentSpec] = []
    piping: List[PipingSpec] = []
    instrumentation: List[InstrumentSpec] = []


class GenerationRequest(BaseModel):
    """Request for P&ID generation"""
    project_id: UUID
    wizard_data: WizardData
    options: Dict[str, Any] = {}


class GenerationResponse(BaseModel):
    """Response for P&ID generation"""
    task_id: str
    status: str
    message: str


class GenerationStatus(BaseModel):
    """Status of P&ID generation"""
    task_id: str
    status: str
    progress: int
    current_step: str
    pid_id: Optional[UUID] = None
    error: Optional[str] = None


# ============================================================================
# Export Schemas
# ============================================================================

class ExportRequest(BaseModel):
    """Request for exporting P&ID"""
    format: str = Field(..., pattern="^(svg|pdf|dxf|json)$")
    options: Dict[str, Any] = {}


class ExportResponse(BaseModel):
    """Response for export request"""
    download_url: str
    filename: str
    format: str
