"""
P&ID (Piping and Instrumentation Diagram) model
"""
from sqlalchemy import Column, String, Text, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from app.database import Base


class PID(Base):
    """P&ID model"""
    __tablename__ = "pids"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    version = Column(String(20), default="1.0")
    description = Column(Text)

    # Canvas data (full diagram state)
    canvas_data = Column(JSONB, default=dict)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Generation metadata (agent info, etc.)
    generation_metadata = Column(JSONB, default=dict)

    # Relationships
    project = relationship("Project", back_populates="pids")
    components = relationship("Component", back_populates="pid", cascade="all, delete-orphan")
    connections = relationship("Connection", back_populates="pid", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<PID(id={self.id}, name='{self.name}', version='{self.version}')>"
