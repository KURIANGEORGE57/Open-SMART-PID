"""
Configuration settings for Smart P&ID Creator
"""
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List


class Settings(BaseSettings):
    """Application settings"""

    # Application
    APP_NAME: str = "Smart P&ID Creator"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    SECRET_KEY: str = "your-secret-key-change-in-production"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://pid_user:password@localhost:5432/smart_pid"

    # Redis
    REDIS_URL: str = "redis://localhost:6379"

    # CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173"
    ]

    # LLM APIs
    OPENAI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    OLLAMA_BASE_URL: str = "http://localhost:11434"

    # Default LLM provider
    LLM_PROVIDER: str = "openai"  # openai, anthropic, ollama
    LLM_MODEL: str = "gpt-4-turbo-preview"

    # Vector Database
    CHROMA_PERSIST_DIR: str = "./chroma_db"

    # File Storage
    MINIO_ENDPOINT: str = "localhost:9000"
    MINIO_ACCESS_KEY: str = "admin"
    MINIO_SECRET_KEY: str = "password"
    MINIO_BUCKET: str = "pid-documents"
    USE_MINIO: bool = False  # Set to True to use MinIO, False for local filesystem
    UPLOAD_DIR: str = "./uploads"

    # YOLOv5 Model
    YOLOV5_MODEL_PATH: str = "../best.pt"
    YOLOV5_CONF_THRESHOLD: float = 0.25
    YOLOV5_IOU_THRESHOLD: float = 0.45

    # Agent Configuration
    AGENT_MAX_ITERATIONS: int = 10
    AGENT_TIMEOUT: int = 300  # seconds

    # Feature Flags
    ENABLE_AGENT_DEBUG: bool = True
    ENABLE_TELEMETRY: bool = False
    ENABLE_YOLOV5_DETECTION: bool = True

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True
    )


# Create settings instance
settings = Settings()
