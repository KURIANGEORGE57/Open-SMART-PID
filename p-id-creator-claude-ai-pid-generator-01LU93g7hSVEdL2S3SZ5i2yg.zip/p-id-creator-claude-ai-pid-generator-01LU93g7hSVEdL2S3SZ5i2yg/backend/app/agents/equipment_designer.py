"""
Equipment Designer Agent

Determines equipment placement and relationships
"""
from typing import Dict, Any
import random

from app.agents.base import BaseAgent, PIDState


class EquipmentDesignerAgent(BaseAgent):
    """
    Designs equipment layout:
    - Determines equipment relationships
    - Assigns preliminary positions
    - Creates equipment connections
    - Applies engineering rules
    """

    def execute(self, state: PIDState) -> PIDState:
        """Design equipment layout"""
        self._log_message(state, "Starting equipment design")

        equipment_list = state["equipment_list"]

        # Analyze equipment relationships
        relationships = self._analyze_relationships(equipment_list, state["piping_specs"])

        # Assign preliminary positions (will be optimized by layout agent)
        positioned_equipment = self._assign_positions(equipment_list, relationships)
        state["equipment_list"] = positioned_equipment

        # Create connections based on process flow
        connections = self._create_connections(positioned_equipment, state["piping_specs"])
        state["connections"] = connections

        self._log_message(
            state,
            f"Equipment design complete: {len(positioned_equipment)} equipment, "
            f"{len(connections)} connections"
        )

        return state

    def _analyze_relationships(
        self,
        equipment: list,
        piping_specs: list
    ) -> Dict[str, Any]:
        """Analyze equipment relationships"""
        relationships = {
            "upstream": {},
            "downstream": {},
            "parallel": []
        }

        # Build relationship map from piping specs
        for spec in piping_specs:
            from_eq = spec.get("from_equipment")
            to_eq = spec.get("to_equipment")

            if from_eq and to_eq:
                if from_eq not in relationships["downstream"]:
                    relationships["downstream"][from_eq] = []
                relationships["downstream"][from_eq].append(to_eq)

                if to_eq not in relationships["upstream"]:
                    relationships["upstream"][to_eq] = []
                relationships["upstream"][to_eq].append(from_eq)

        return relationships

    def _assign_positions(
        self,
        equipment: list,
        relationships: Dict[str, Any]
    ) -> list:
        """Assign preliminary positions to equipment"""
        positioned_equipment = []

        # Simple grid layout (will be improved by layout optimizer)
        grid_size = 150
        items_per_row = 4
        x_offset = 100
        y_offset = 100

        for i, eq in enumerate(equipment):
            row = i // items_per_row
            col = i % items_per_row

            positioned_eq = {
                **eq,
                "position": {
                    "x": x_offset + (col * grid_size),
                    "y": y_offset + (row * grid_size)
                },
                "rotation": 0,
                "scale": 1.0
            }
            positioned_equipment.append(positioned_eq)

        return positioned_equipment

    def _create_connections(
        self,
        equipment: list,
        piping_specs: list
    ) -> list:
        """Create connections between equipment"""
        connections = []

        # Create equipment tag map
        eq_map = {eq["tag"]: eq for eq in equipment}

        for spec in piping_specs:
            from_tag = spec.get("from_equipment")
            to_tag = spec.get("to_equipment")

            if from_tag in eq_map and to_tag in eq_map:
                from_eq = eq_map[from_tag]
                to_eq = eq_map[to_tag]

                connection = {
                    "from": from_tag,
                    "to": to_tag,
                    "line_number": f"LINE-{len(connections) + 1:03d}",
                    "fluid_service": spec.get("fluid_service", "Unknown"),
                    "line_size": spec.get("line_size"),
                    "material": spec.get("material"),
                    "path": self._generate_path(
                        from_eq["position"],
                        to_eq["position"]
                    )
                }
                connections.append(connection)

        return connections

    def _generate_path(
        self,
        from_pos: Dict[str, float],
        to_pos: Dict[str, float]
    ) -> list:
        """Generate path points for connection"""
        # Simple straight line for now (will be enhanced)
        return [
            {"x": from_pos["x"], "y": from_pos["y"]},
            {"x": to_pos["x"], "y": to_pos["y"]}
        ]
