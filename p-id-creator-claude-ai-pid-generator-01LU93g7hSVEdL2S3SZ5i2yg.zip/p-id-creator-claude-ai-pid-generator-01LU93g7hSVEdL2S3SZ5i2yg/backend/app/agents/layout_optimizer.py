"""
Layout Optimizer Agent

Optimizes component placement for readability and standards compliance
"""
from typing import Dict, Any, List
import math

from app.agents.base import BaseAgent, PIDState


class LayoutOptimizerAgent(BaseAgent):
    """
    Optimizes component layout:
    - Minimizes line crossings
    - Ensures proper spacing
    - Aligns components to grid
    - Applies flow direction (left-to-right)
    - Follows layout best practices
    """

    def __init__(self, name: str):
        super().__init__(name)
        self.grid_size = 25
        self.min_spacing = 100
        self.flow_direction = "left_to_right"

    def execute(self, state: PIDState) -> PIDState:
        """Optimize layout"""
        self._log_message(state, "Starting layout optimization")

        equipment = state["equipment_list"]
        connections = state["connections"]

        # Optimize positions
        optimized_equipment = self._optimize_positions(equipment, connections)
        state["equipment_list"] = optimized_equipment

        # Update connection paths
        optimized_connections = self._optimize_paths(optimized_equipment, connections)
        state["connections"] = optimized_connections

        # Store layout metadata
        state["layout_plan"] = {
            "grid_size": self.grid_size,
            "bounds": self._calculate_bounds(optimized_equipment),
            "optimization_applied": True
        }

        self._log_message(state, "Layout optimization complete")

        return state

    def _optimize_positions(
        self,
        equipment: List[Dict[str, Any]],
        connections: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Optimize equipment positions"""
        optimized = []

        # Build dependency graph
        graph = self._build_dependency_graph(equipment, connections)

        # Topological sort for left-to-right flow
        sorted_equipment = self._topological_sort(equipment, graph)

        # Assign positions based on flow
        for i, eq in enumerate(sorted_equipment):
            level = graph["levels"].get(eq["tag"], 0)

            optimized_eq = {
                **eq,
                "position": {
                    "x": self._snap_to_grid(100 + level * 200),
                    "y": self._snap_to_grid(100 + i * 150)
                }
            }
            optimized.append(optimized_eq)

        return optimized

    def _optimize_paths(
        self,
        equipment: List[Dict[str, Any]],
        connections: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Optimize connection paths"""
        eq_map = {eq["tag"]: eq for eq in equipment}
        optimized_connections = []

        for conn in connections:
            from_tag = conn["from"]
            to_tag = conn["to"]

            if from_tag in eq_map and to_tag in eq_map:
                from_pos = eq_map[from_tag]["position"]
                to_pos = eq_map[to_tag]["position"]

                # Generate orthogonal path (right angles)
                path = self._generate_orthogonal_path(from_pos, to_pos)

                optimized_conn = {
                    **conn,
                    "path": path
                }
                optimized_connections.append(optimized_conn)

        return optimized_connections

    def _snap_to_grid(self, value: float) -> float:
        """Snap value to grid"""
        return round(value / self.grid_size) * self.grid_size

    def _build_dependency_graph(
        self,
        equipment: List[Dict[str, Any]],
        connections: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Build dependency graph for topological sort"""
        graph = {
            "edges": {},
            "levels": {}
        }

        # Build adjacency list
        for eq in equipment:
            graph["edges"][eq["tag"]] = []

        for conn in connections:
            from_tag = conn["from"]
            to_tag = conn["to"]
            if from_tag in graph["edges"]:
                graph["edges"][from_tag].append(to_tag)

        # Calculate levels (distance from source)
        for eq in equipment:
            if eq["tag"] not in graph["levels"]:
                self._calculate_level(eq["tag"], graph, 0)

        return graph

    def _calculate_level(
        self,
        tag: str,
        graph: Dict[str, Any],
        current_level: int
    ):
        """Calculate level in graph (recursive)"""
        if tag in graph["levels"]:
            graph["levels"][tag] = max(graph["levels"][tag], current_level)
        else:
            graph["levels"][tag] = current_level

        # Process downstream equipment
        for downstream in graph["edges"].get(tag, []):
            self._calculate_level(downstream, graph, current_level + 1)

    def _topological_sort(
        self,
        equipment: List[Dict[str, Any]],
        graph: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Sort equipment by dependency order"""
        return sorted(equipment, key=lambda eq: graph["levels"].get(eq["tag"], 0))

    def _generate_orthogonal_path(
        self,
        from_pos: Dict[str, float],
        to_pos: Dict[str, float]
    ) -> List[Dict[str, float]]:
        """Generate orthogonal (right-angle) path"""
        # Simple L-shaped path
        mid_x = (from_pos["x"] + to_pos["x"]) / 2

        return [
            {"x": from_pos["x"], "y": from_pos["y"]},
            {"x": mid_x, "y": from_pos["y"]},
            {"x": mid_x, "y": to_pos["y"]},
            {"x": to_pos["x"], "y": to_pos["y"]}
        ]

    def _calculate_bounds(
        self,
        equipment: List[Dict[str, Any]]
    ) -> Dict[str, float]:
        """Calculate bounding box for layout"""
        if not equipment:
            return {"min_x": 0, "min_y": 0, "max_x": 0, "max_y": 0}

        positions = [eq["position"] for eq in equipment]
        xs = [pos["x"] for pos in positions]
        ys = [pos["y"] for pos in positions]

        return {
            "min_x": min(xs),
            "min_y": min(ys),
            "max_x": max(xs),
            "max_y": max(ys)
        }
