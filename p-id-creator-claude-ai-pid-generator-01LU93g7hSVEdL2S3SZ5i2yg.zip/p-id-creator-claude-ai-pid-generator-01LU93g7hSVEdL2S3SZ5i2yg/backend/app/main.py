"""
Smart P&ID Creator - Main FastAPI Application
"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.database import engine, Base

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown events"""
    # Startup
    logger.info("Starting Smart P&ID Creator API")
    logger.info(f"Environment: {settings.ENVIRONMENT}")

    # Create database tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield

    # Shutdown
    logger.info("Shutting down Smart P&ID Creator API")


# Initialize FastAPI app
app = FastAPI(
    title="Smart P&ID Creator API",
    description="AI-powered P&ID generation and management system",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "environment": settings.ENVIRONMENT
    }


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Smart P&ID Creator API",
        "version": "1.0.0",
        "docs": "/docs"
    }


# WebSocket manager for real-time updates
class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, list[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, pid_id: str):
        await websocket.accept()
        if pid_id not in self.active_connections:
            self.active_connections[pid_id] = []
        self.active_connections[pid_id].append(websocket)

    def disconnect(self, websocket: WebSocket, pid_id: str):
        if pid_id in self.active_connections:
            self.active_connections[pid_id].remove(websocket)

    async def send_personal_message(self, message: dict, websocket: WebSocket):
        await websocket.send_json(message)

    async def broadcast(self, message: dict, pid_id: str):
        if pid_id in self.active_connections:
            for connection in self.active_connections[pid_id]:
                await connection.send_json(message)


manager = ConnectionManager()


@app.websocket("/ws/{pid_id}")
async def websocket_endpoint(websocket: WebSocket, pid_id: str):
    """WebSocket endpoint for real-time P&ID updates"""
    await manager.connect(websocket, pid_id)
    try:
        while True:
            data = await websocket.receive_json()
            # Handle different message types
            if data.get("type") == "component_update":
                await manager.broadcast(data, pid_id)
            elif data.get("type") == "subscribe":
                await manager.send_personal_message(
                    {"type": "subscribed", "pid_id": pid_id},
                    websocket
                )
    except WebSocketDisconnect:
        manager.disconnect(websocket, pid_id)
        await manager.broadcast(
            {"type": "user_left", "pid_id": pid_id},
            pid_id
        )


# Import and include routers
from app.api import projects, pids, components, wizard

app.include_router(projects.router, prefix="/api/v1/projects", tags=["projects"])
app.include_router(pids.router, prefix="/api/v1/pids", tags=["pids"])
app.include_router(components.router, prefix="/api/v1/components", tags=["components"])
app.include_router(wizard.router, prefix="/api/v1/wizard", tags=["wizard"])
# app.include_router(export.router, prefix="/api/v1/export", tags=["export"])  # TODO: Implement export


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.ENVIRONMENT == "development"
    )
