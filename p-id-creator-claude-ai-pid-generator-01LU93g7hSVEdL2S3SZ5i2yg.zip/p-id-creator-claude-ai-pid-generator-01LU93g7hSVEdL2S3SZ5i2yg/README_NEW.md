# Smart P&ID Creator

> **AI-powered Piping and Instrumentation Diagram generation system**

An open-source autonomous P&ID generation system that uses AI agents to create interactive, data-rich engineering diagrams from natural language instructions. Features a guided wizard for requirement gathering and produces smart P&IDs where every component is clickable and displays relevant engineering data.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Python](https://img.shields.io/badge/python-3.11+-blue)
![React](https://img.shields.io/badge/react-18.2+-blue)

## 🌟 Features

### 🤖 AI-Powered Generation
- Describe your process in plain English
- Multi-agent system (LangGraph) for intelligent P&ID design
- Automatic equipment placement and line routing
- Compliance with industry standards (ISA, ISO, ANSI)

### 🎯 Guided Wizard Interface
- Step-by-step requirement gathering
- Process description with AI suggestions
- Equipment, piping, and instrumentation specification
- Template library for common processes

### 🎨 Interactive Smart P&IDs
- **Clickable components** - View detailed properties for any element
- **Live editing** - Drag-and-drop repositioning
- **Real-time collaboration** - WebSocket-based multi-user editing
- **Rich data** - Equipment specs, line lists, instrument details

### 📤 Professional Exports
- Vector formats: SVG, PDF (high-quality printing)
- CAD formats: DXF (AutoCAD compatible)
- Data exports: JSON, Excel
- Automated reports: Equipment lists, line lists, instrument index

### 🔍 Symbol Detection (YOLOv5)
- Trained on 33+ P&ID symbol types
- Import existing P&IDs via image recognition
- Automatic symbol extraction and digitization

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (React + TypeScript)             │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │   Wizard    │  │  P&ID Canvas │  │  Component Props │  │
│  │  Interface  │  │   (Konva.js) │  │     Inspector    │  │
│  └─────────────┘  └──────────────┘  └──────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                             │
                    ┌────────▼────────┐
                    │   FastAPI       │
                    └────────┬────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
┌───────▼────────┐  ┌────────▼────────┐  ┌──────▼──────┐
│  Agent Service │  │  Data Service   │  │   Export    │
│  (LangGraph)   │  │  (PostgreSQL)   │  │   Service   │
│                │  │  (ChromaDB)     │  │             │
└────────────────┘  └─────────────────┘  └─────────────┘
```

## 🚀 Quick Start

### Prerequisites

- **Docker & Docker Compose** (recommended)
- OR:
  - Python 3.11+
  - Node.js 20+
  - PostgreSQL 15+
  - Redis 7+

### Option 1: Docker (Recommended)

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/p-id-symbols.git
cd p-id-symbols

# 2. Copy environment file
cp .env.example .env

# 3. Edit .env and add your API keys
# Required: OPENAI_API_KEY or ANTHROPIC_API_KEY
nano .env

# 4. Start all services
docker-compose up -d

# 5. Access the application
# Frontend: http://localhost:3000
# Backend API: http://localhost:8000/docs
```

### Option 2: Local Development

#### Backend Setup

```bash
# Navigate to backend
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
cp ../.env.example .env
# Edit .env with your configuration

# Run database migrations (if using local PostgreSQL)
alembic upgrade head

# Start the backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

#### Frontend Setup

```bash
# Navigate to frontend (new terminal)
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Access the application at `http://localhost:3000`

## 📖 Usage Guide

### Creating Your First P&ID

1. **Start the Wizard**
   - Click "Create New P&ID" from the home page
   - Enter project information (name, industry type, standard)

2. **Describe Your Process**
   - Write a natural language description of your process
   - Example: *"A simple mixing process with two feed pumps, a mixing tank with agitator, temperature control, and level indication"*

3. **Review Equipment**
   - AI extracts equipment from your description
   - Add, edit, or remove equipment as needed
   - Specify properties (size, material, ratings)

4. **Generate P&ID**
   - Review all inputs
   - Click "Generate P&ID"
   - AI agents create the diagram (30-60 seconds)

5. **Edit & Refine**
   - Click components to view/edit properties
   - Drag to reposition elements
   - Add notes and documentation

6. **Export**
   - Export as PDF for printing
   - Export as DXF for AutoCAD
   - Generate equipment lists and reports

## 🧪 Technology Stack

### Backend
- **FastAPI** - Modern Python web framework
- **LangGraph** - Multi-agent orchestration
- **SQLAlchemy** - ORM and database management
- **PostgreSQL** - Primary database
- **ChromaDB** - Vector database for knowledge base
- **YOLOv5** - Symbol detection (PyTorch)

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **Konva.js** - Canvas rendering
- **Zustand** - State management
- **Tailwind CSS** - Styling
- **Vite** - Build tool

### Infrastructure
- **Docker** - Containerization
- **Redis** - Caching and sessions
- **MinIO** - Object storage (optional)

## 🔧 Configuration

### Environment Variables

Key configuration options in `.env`:

```bash
# LLM Provider
LLM_PROVIDER=openai          # openai, anthropic, or ollama
LLM_MODEL=gpt-4-turbo-preview
OPENAI_API_KEY=sk-...

# Database
DATABASE_URL=postgresql+asyncpg://...

# Features
ENABLE_YOLOV5_DETECTION=true
ENABLE_AGENT_DEBUG=true
```

### Using Local LLMs (Ollama)

For offline/local operation:

```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Pull a model
ollama pull llama3

# Update .env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
LLM_MODEL=llama3
```

## 📚 Documentation

- [**Complete Blueprint**](./SMART_PID_BLUEPRINT.md) - Full project specification
- [**API Documentation**](http://localhost:8000/docs) - Interactive API docs (when running)
- [**Architecture Guide**](./docs/ARCHITECTURE.md) - System design details
- [**Contributing Guide**](./CONTRIBUTING.md) - How to contribute

## 🛠️ Development

### Project Structure

```
p-id-symbols/
├── backend/               # FastAPI backend
│   ├── app/
│   │   ├── api/          # API routes
│   │   ├── agents/       # AI agents (LangGraph)
│   │   ├── models/       # Database models
│   │   ├── services/     # Business logic
│   │   └── utils/        # Utilities
│   └── tests/
├── frontend/             # React frontend
│   ├── src/
│   │   ├── components/   # React components
│   │   ├── pages/        # Page components
│   │   ├── stores/       # State management
│   │   └── services/     # API clients
│   └── public/
├── best.pt               # YOLOv5 trained model
├── dataset.yaml          # Symbol detection config
└── docker-compose.yml    # Docker orchestration
```

### Running Tests

```bash
# Backend tests
cd backend
pytest

# Frontend tests
cd frontend
npm test

# E2E tests (with Playwright)
npm run test:e2e
```

## 🎯 Roadmap

### Phase 1: Foundation ✅
- [x] Project structure
- [x] Backend API skeleton
- [x] Database models
- [x] Frontend setup
- [ ] Basic wizard interface

### Phase 2: Core Features (In Progress)
- [ ] Complete wizard implementation
- [ ] Agent system (LangGraph)
- [ ] Interactive canvas
- [ ] Component inspector

### Phase 3: Advanced Features
- [ ] YOLOv5 integration
- [ ] Real-time collaboration
- [ ] Advanced exports (DXF, reports)
- [ ] Template library

### Phase 4: Polish & Launch
- [ ] Performance optimization
- [ ] Comprehensive testing
- [ ] Documentation
- [ ] Open source release

## 🤝 Contributing

We welcome contributions! Here's how to get started:

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes
4. Run tests: `pytest` and `npm test`
5. Commit: `git commit -m 'Add amazing feature'`
6. Push: `git push origin feature/amazing-feature`
7. Open a Pull Request

See [CONTRIBUTING.md](./CONTRIBUTING.md) for detailed guidelines.

## 📄 License

This project is licensed under the MIT License - see [LICENSE](./LICENSE) file for details.

## 🙏 Acknowledgments

- **Original P&ID Symbol Detection**: Based on [YOLOv5 for symbol extraction in P&ID diagrams](https://www.researchgate.net/publication/366123842_YOLOv5_for_symbol_extraction_in_PID_diagrams)
- **Dataset**: [P&ID Symbols Dataset on Kaggle](https://www.kaggle.com/datasets/hristohristov21/pid-symbols)
- **Inspired by**: ISA S5.1 standard for instrumentation symbols

## 📧 Contact & Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/p-id-symbols/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/p-id-symbols/discussions)
- **Discord**: [Join our community](#) *(coming soon)*

---

**Built with ❤️ by the Smart P&ID Creator team**

*Making engineering design faster, smarter, and more collaborative.*
