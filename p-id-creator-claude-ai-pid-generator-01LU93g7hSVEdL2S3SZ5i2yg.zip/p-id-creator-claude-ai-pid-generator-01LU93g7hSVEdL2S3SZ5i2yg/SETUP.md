# Setup Guide - Smart P&ID Creator

This guide provides detailed setup instructions for the Smart P&ID Creator.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start with Docker](#quick-start-with-docker)
3. [Local Development Setup](#local-development-setup)
4. [Configuration](#configuration)
5. [Troubleshooting](#troubleshooting)

## Prerequisites

### Option 1: Docker (Recommended)

- Docker Desktop 20.10+
- Docker Compose 2.0+
- 4GB RAM minimum (8GB recommended)

### Option 2: Local Development

- **Python**: 3.11 or higher
- **Node.js**: 20.0 or higher
- **PostgreSQL**: 15 or higher
- **Redis**: 7 or higher
- **Git**: Latest version

## Quick Start with Docker

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/p-id-symbols.git
cd p-id-symbols
```

### 2. Configure Environment

```bash
# Copy example environment file
cp .env.example .env

# Edit environment file
nano .env  # or use your preferred editor
```

**Required configuration:**

```bash
# At minimum, set one of these:
OPENAI_API_KEY=sk-your-key-here
# OR
ANTHROPIC_API_KEY=sk-ant-your-key-here

# Database password (change default)
DB_PASSWORD=your_secure_password_here

# Secret key (generate with: openssl rand -hex 32)
SECRET_KEY=your_secret_key_here
```

### 3. Start Services

```bash
# Start all services in detached mode
docker-compose up -d

# Check logs
docker-compose logs -f

# Check status
docker-compose ps
```

### 4. Access Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs
- **MinIO Console**: http://localhost:9001 (if enabled)

### 5. Stop Services

```bash
# Stop all services
docker-compose down

# Stop and remove volumes (WARNING: deletes all data)
docker-compose down -v
```

## Local Development Setup

### Backend Setup

#### 1. Install Python Dependencies

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Upgrade pip
pip install --upgrade pip

# Install dependencies
pip install -r requirements.txt
```

#### 2. Set Up PostgreSQL

```bash
# Install PostgreSQL (if not already installed)
# On Ubuntu/Debian:
sudo apt-get install postgresql postgresql-contrib

# On macOS (with Homebrew):
brew install postgresql@15

# Start PostgreSQL
# On Linux:
sudo systemctl start postgresql
# On macOS:
brew services start postgresql@15

# Create database and user
sudo -u postgres psql
```

In PostgreSQL shell:

```sql
CREATE DATABASE smart_pid;
CREATE USER pid_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE smart_pid TO pid_user;
\q
```

#### 3. Set Up Redis

```bash
# Install Redis
# On Ubuntu/Debian:
sudo apt-get install redis-server

# On macOS:
brew install redis

# Start Redis
# On Linux:
sudo systemctl start redis
# On macOS:
brew services start redis
```

#### 4. Configure Backend Environment

```bash
# Create .env file in backend directory
cd backend
cp ../.env.example .env

# Edit .env with your local configuration
nano .env
```

Update these values for local development:

```bash
DATABASE_URL=postgresql+asyncpg://pid_user:your_password@localhost:5432/smart_pid
REDIS_URL=redis://localhost:6379
OPENAI_API_KEY=sk-your-key-here
ENVIRONMENT=development
```

#### 5. Run Database Migrations

```bash
# Install Alembic (if not in requirements.txt)
pip install alembic

# Initialize Alembic (first time only)
alembic init migrations

# Create initial migration
alembic revision --autogenerate -m "Initial migration"

# Run migrations
alembic upgrade head
```

#### 6. Start Backend Server

```bash
# From backend directory
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Backend should now be running at http://localhost:8000

### Frontend Setup

#### 1. Install Node.js Dependencies

```bash
# Open new terminal
cd frontend

# Install dependencies
npm install

# If you encounter errors, try:
npm install --legacy-peer-deps
```

#### 2. Configure Frontend Environment

```bash
# Create .env.local file
cat > .env.local << EOF
VITE_API_URL=http://localhost:8000
VITE_WS_URL=ws://localhost:8000
EOF
```

#### 3. Start Development Server

```bash
# Start Vite dev server
npm run dev
```

Frontend should now be running at http://localhost:3000

## Configuration

### LLM Provider Configuration

#### Using OpenAI

```bash
# In .env
LLM_PROVIDER=openai
LLM_MODEL=gpt-4-turbo-preview
OPENAI_API_KEY=sk-...
```

#### Using Anthropic Claude

```bash
# In .env
LLM_PROVIDER=anthropic
LLM_MODEL=claude-3-opus-20240229
ANTHROPIC_API_KEY=sk-ant-...
```

#### Using Local LLM (Ollama)

```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Pull a model
ollama pull llama3

# Configure in .env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
LLM_MODEL=llama3
```

### YOLOv5 Symbol Detection

The trained YOLOv5 model (`best.pt`) should be in the root directory. If not:

```bash
# Download from repository releases
wget https://github.com/ch-hristov/p-id-symbols/raw/main/best.pt

# Or train your own
cd backend
python -m app.utils.train_yolov5
```

### Database Configuration

#### PostgreSQL Connection Strings

```bash
# Local PostgreSQL
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/database

# Docker PostgreSQL
DATABASE_URL=postgresql+asyncpg://user:password@postgres:5432/database

# Cloud PostgreSQL (e.g., Supabase, Render)
DATABASE_URL=postgresql+asyncpg://user:password@host.com:5432/database?ssl=require
```

#### Running Migrations

```bash
# Create new migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1

# View migration history
alembic history
```

## Troubleshooting

### Common Issues

#### Backend won't start

**Issue**: `ModuleNotFoundError` or import errors

**Solution**:
```bash
# Ensure virtual environment is activated
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

**Issue**: Database connection error

**Solution**:
```bash
# Check PostgreSQL is running
sudo systemctl status postgresql

# Verify credentials in .env
# Test connection
psql -U pid_user -d smart_pid -h localhost
```

#### Frontend won't start

**Issue**: `EADDRINUSE` port already in use

**Solution**:
```bash
# Kill process on port 3000
# On Linux/Mac:
lsof -ti:3000 | xargs kill -9

# On Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

**Issue**: Module not found errors

**Solution**:
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

#### Docker issues

**Issue**: Containers won't start

**Solution**:
```bash
# Check Docker status
docker ps -a

# View logs for specific service
docker-compose logs backend

# Rebuild images
docker-compose build --no-cache
docker-compose up -d
```

**Issue**: Permission errors

**Solution**:
```bash
# Fix ownership (Linux)
sudo chown -R $USER:$USER .

# Or run Docker commands with sudo
sudo docker-compose up -d
```

### Getting Help

1. **Check logs**:
   ```bash
   # Docker
   docker-compose logs -f backend
   docker-compose logs -f frontend

   # Local
   # Backend logs appear in terminal
   # Frontend logs in browser console
   ```

2. **Verify environment**:
   ```bash
   # Check .env file exists and is configured
   cat .env

   # Verify services are running
   docker-compose ps  # Docker
   netstat -tulpn | grep -E '8000|3000|5432|6379'  # Local
   ```

3. **Search issues**: Check [GitHub Issues](https://github.com/yourusername/p-id-symbols/issues)

4. **Ask for help**: Create a new issue with:
   - Error message
   - Steps to reproduce
   - Environment details (OS, versions)
   - Relevant logs

## Next Steps

After successful setup:

1. ✅ Access the application at http://localhost:3000
2. ✅ Create your first project
3. ✅ Try the wizard interface
4. ✅ Generate a P&ID
5. ✅ Explore the interactive canvas

For more information:
- [README.md](./README_NEW.md) - Project overview
- [API Documentation](http://localhost:8000/docs) - Backend API
- [Contributing Guide](./CONTRIBUTING.md) - How to contribute

Happy building! 🚀
