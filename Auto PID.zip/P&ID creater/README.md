# AutoPID: Autonomous P&ID Creator

## Mission Statement
Create an open-source AI-powered tool that transforms natural language process descriptions into industry-standard P&IDs, democratizing process engineering design and accelerating preliminary engineering workflows.

## Quick Start
```bash
pip install -r requirements.txt
python -m autopid.ui.wizard
```
