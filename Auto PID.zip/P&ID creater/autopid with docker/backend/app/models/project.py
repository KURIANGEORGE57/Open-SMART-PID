"""
Project model
"""
from sqlalchemy import Column, String, Text, DateTime, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from app.database import Base


class IndustryType(str, enum.Enum):
    """Industry types"""
    OIL_GAS = "Oil & Gas"
    PETROCHEMICAL = "Petrochemical"
    CHEMICAL = "Chemical"
    PHARMACEUTICAL = "Pharmaceutical"
    WATER_TREATMENT = "Water Treatment"
    POWER_GENERATION = "Power Generation"
    FOOD_BEVERAGE = "Food & Beverage"
    OTHER = "Other"


class StandardType(str, enum.Enum):
    """P&ID Standards"""
    ISA = "ISA"
    ISO = "ISO"
    ANSI = "ANSI"
    DIN = "DIN"


class ProjectStatus(str, enum.Enum):
    """Project status"""
    DRAFT = "draft"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class Project(Base):
    """Project model"""
    __tablename__ = "projects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    industry_type = Column(Enum(IndustryType), nullable=False, default=IndustryType.OTHER)
    standard = Column(Enum(StandardType), nullable=False, default=StandardType.ISA)
    status = Column(Enum(ProjectStatus), nullable=False, default=ProjectStatus.DRAFT)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    owner_id = Column(UUID(as_uuid=True))  # Will link to User model

    # Additional project data (wizard responses, etc.)
    project_data = Column(JSONB, default=dict)

    # Relationships
    pids = relationship("PID", back_populates="project", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Project(id={self.id}, name='{self.name}')>"
