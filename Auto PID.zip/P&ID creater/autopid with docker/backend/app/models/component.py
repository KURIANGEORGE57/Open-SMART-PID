"""
Component models (Equipment, Valves, Instruments)
"""
from sqlalchemy import Column, String, Float, DateTime, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from app.database import Base


class ComponentCategory(str, enum.Enum):
    """Component categories"""
    EQUIPMENT = "equipment"
    VALVE = "valve"
    INSTRUMENT = "instrument"
    LINE = "line"
    FITTING = "fitting"
    ANNOTATION = "annotation"


class ComponentType(str, enum.Enum):
    """Specific component types"""
    # Equipment
    TANK = "tank"
    REACTOR = "reactor"
    COLUMN = "column"
    SEPARATOR = "separator"
    PUMP = "pump"
    COMPRESSOR = "compressor"
    HEAT_EXCHANGER = "heat_exchanger"
    FILTER = "filter"
    MIXER = "mixer"

    # Valves (from YOLOv5 dataset)
    GATE_VALVE = "gate_valve"
    BALL_VALVE = "ball_valve"
    GLOBE_VALVE = "globe_valve"
    BUTTERFLY_VALVE = "butterfly_valve"
    CHECK_VALVE = "check_valve"
    CONTROL_VALVE = "control_valve"
    PLUG_VALVE = "plug_valve"
    DIAPHRAGM_VALVE = "diaphragm_valve"
    NEEDLE_VALVE = "needle_valve"

    # Instruments
    PRESSURE_INDICATOR = "pressure_indicator"
    TEMPERATURE_INDICATOR = "temperature_indicator"
    FLOW_INDICATOR = "flow_indicator"
    LEVEL_INDICATOR = "level_indicator"
    CONTROLLER = "controller"
    TRANSMITTER = "transmitter"

    # Fittings
    REDUCER = "reducer"
    FLANGE = "flange"
    TEE = "tee"
    ELBOW = "elbow"


class Component(Base):
    """Component model"""
    __tablename__ = "components"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    pid_id = Column(UUID(as_uuid=True), ForeignKey("pids.id"), nullable=False, index=True)

    # Component identification
    tag = Column(String(100), nullable=False, index=True, unique=True)
    category = Column(Enum(ComponentCategory), nullable=False, index=True)
    component_type = Column(Enum(ComponentType), nullable=False)
    symbol_type = Column(String(100))  # Maps to symbol library

    # Position and appearance
    position_x = Column(Float, nullable=False)
    position_y = Column(Float, nullable=False)
    rotation = Column(Float, default=0.0)
    scale = Column(Float, default=1.0)

    # Component properties (flexible JSON)
    properties = Column(JSONB, default=dict)

    # Metadata
    metadata = Column(JSONB, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Notes and documentation
    notes = Column(ARRAY(String), default=list)
    documents = Column(JSONB, default=list)  # List of document references

    # Relationships
    pid = relationship("PID", back_populates="components")
    outgoing_connections = relationship(
        "Connection",
        foreign_keys="Connection.from_component_id",
        back_populates="from_component"
    )
    incoming_connections = relationship(
        "Connection",
        foreign_keys="Connection.to_component_id",
        back_populates="to_component"
    )

    def __repr__(self):
        return f"<Component(id={self.id}, tag='{self.tag}', type='{self.component_type}')>"


class LineType(str, enum.Enum):
    """Line types"""
    PROCESS = "process"
    UTILITY = "utility"
    INSTRUMENT = "instrument"
    SIGNAL = "signal"


class Connection(Base):
    """Connection/Line model"""
    __tablename__ = "connections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    pid_id = Column(UUID(as_uuid=True), ForeignKey("pids.id"), nullable=False, index=True)

    # Connection identification
    line_number = Column(String(100), index=True)
    line_type = Column(Enum(LineType), nullable=False, default=LineType.PROCESS)

    # Connected components
    from_component_id = Column(UUID(as_uuid=True), ForeignKey("components.id"))
    to_component_id = Column(UUID(as_uuid=True), ForeignKey("components.id"))

    # Line properties
    fluid_service = Column(String(100))
    line_size = Column(String(50))
    piping_class = Column(String(50))
    material = Column(String(100))

    # Path data (SVG path or waypoints)
    path_data = Column(JSONB, default=dict)

    # Additional properties
    properties = Column(JSONB, default=dict)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    pid = relationship("PID", back_populates="connections")
    from_component = relationship(
        "Component",
        foreign_keys=[from_component_id],
        back_populates="outgoing_connections"
    )
    to_component = relationship(
        "Component",
        foreign_keys=[to_component_id],
        back_populates="incoming_connections"
    )

    def __repr__(self):
        return f"<Connection(id={self.id}, line_number='{self.line_number}')>"
