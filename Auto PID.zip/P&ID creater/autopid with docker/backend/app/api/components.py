"""
Components API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
from uuid import UUID

from app.database import get_db
from app.models.component import Component, Connection
from app.models.pid import PID
from app.models.schemas import (
    ComponentCreate, ComponentUpdate, ComponentResponse,
    ConnectionCreate, ConnectionUpdate, ConnectionResponse
)

router = APIRouter()


# ============================================================================
# Component Endpoints
# ============================================================================

@router.post("/", response_model=ComponentResponse, status_code=status.HTTP_201_CREATED)
async def create_component(
    component_data: ComponentCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new component"""
    # Verify PID exists
    result = await db.execute(
        select(PID).where(PID.id == component_data.pid_id)
    )
    pid = result.scalar_one_or_none()

    if not pid:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="P&ID not found"
        )

    component = Component(
        pid_id=component_data.pid_id,
        tag=component_data.tag,
        category=component_data.category,
        component_type=component_data.component_type,
        position_x=component_data.position_x,
        position_y=component_data.position_y,
        rotation=component_data.rotation,
        scale=component_data.scale,
        properties=component_data.properties,
    )

    db.add(component)
    await db.commit()
    await db.refresh(component)

    return component


@router.get("/", response_model=List[ComponentResponse])
async def list_components(
    pid_id: UUID = None,
    category: str = None,
    skip: int = 0,
    limit: int = 1000,
    db: AsyncSession = Depends(get_db)
):
    """List components, optionally filtered by PID or category"""
    query = select(Component)

    if pid_id:
        query = query.where(Component.pid_id == pid_id)

    if category:
        query = query.where(Component.category == category)

    query = query.offset(skip).limit(limit).order_by(Component.created_at)

    result = await db.execute(query)
    components = result.scalars().all()
    return components


@router.get("/{component_id}", response_model=ComponentResponse)
async def get_component(
    component_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get a specific component"""
    result = await db.execute(
        select(Component).where(Component.id == component_id)
    )
    component = result.scalar_one_or_none()

    if not component:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Component not found"
        )

    return component


@router.patch("/{component_id}", response_model=ComponentResponse)
async def update_component(
    component_id: UUID,
    component_data: ComponentUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update a component"""
    result = await db.execute(
        select(Component).where(Component.id == component_id)
    )
    component = result.scalar_one_or_none()

    if not component:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Component not found"
        )

    # Update fields
    update_data = component_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        if value is not None:
            setattr(component, field, value)

    await db.commit()
    await db.refresh(component)

    return component


@router.delete("/{component_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_component(
    component_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete a component"""
    result = await db.execute(
        select(Component).where(Component.id == component_id)
    )
    component = result.scalar_one_or_none()

    if not component:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Component not found"
        )

    await db.delete(component)
    await db.commit()

    return None


# ============================================================================
# Connection Endpoints
# ============================================================================

@router.post("/connections", response_model=ConnectionResponse, status_code=status.HTTP_201_CREATED)
async def create_connection(
    connection_data: ConnectionCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new connection"""
    # Verify PID exists
    result = await db.execute(
        select(PID).where(PID.id == connection_data.pid_id)
    )
    pid = result.scalar_one_or_none()

    if not pid:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="P&ID not found"
        )

    connection = Connection(
        pid_id=connection_data.pid_id,
        line_number=connection_data.line_number,
        line_type=connection_data.line_type,
        from_component_id=connection_data.from_component_id,
        to_component_id=connection_data.to_component_id,
        fluid_service=connection_data.fluid_service,
        line_size=connection_data.line_size,
        piping_class=connection_data.piping_class,
        material=connection_data.material,
        path_data=connection_data.path_data,
        properties=connection_data.properties,
    )

    db.add(connection)
    await db.commit()
    await db.refresh(connection)

    return connection


@router.get("/connections", response_model=List[ConnectionResponse])
async def list_connections(
    pid_id: UUID = None,
    skip: int = 0,
    limit: int = 1000,
    db: AsyncSession = Depends(get_db)
):
    """List connections, optionally filtered by PID"""
    query = select(Connection)

    if pid_id:
        query = query.where(Connection.pid_id == pid_id)

    query = query.offset(skip).limit(limit).order_by(Connection.created_at)

    result = await db.execute(query)
    connections = result.scalars().all()
    return connections


@router.get("/connections/{connection_id}", response_model=ConnectionResponse)
async def get_connection(
    connection_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get a specific connection"""
    result = await db.execute(
        select(Connection).where(Connection.id == connection_id)
    )
    connection = result.scalar_one_or_none()

    if not connection:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Connection not found"
        )

    return connection


@router.patch("/connections/{connection_id}", response_model=ConnectionResponse)
async def update_connection(
    connection_id: UUID,
    connection_data: ConnectionUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update a connection"""
    result = await db.execute(
        select(Connection).where(Connection.id == connection_id)
    )
    connection = result.scalar_one_or_none()

    if not connection:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Connection not found"
        )

    # Update fields
    update_data = connection_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        if value is not None:
            setattr(connection, field, value)

    await db.commit()
    await db.refresh(connection)

    return connection


@router.delete("/connections/{connection_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_connection(
    connection_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete a connection"""
    result = await db.execute(
        select(Connection).where(Connection.id == connection_id)
    )
    connection = result.scalar_one_or_none()

    if not connection:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Connection not found"
        )

    await db.delete(connection)
    await db.commit()

    return None
