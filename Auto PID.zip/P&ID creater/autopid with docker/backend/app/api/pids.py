"""
PIDs API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
from uuid import UUID

from app.database import get_db
from app.models.pid import PID
from app.models.project import Project
from app.models.schemas import PIDCreate, PIDUpdate, PIDResponse

router = APIRouter()


@router.post("/", response_model=PIDResponse, status_code=status.HTTP_201_CREATED)
async def create_pid(
    pid_data: PIDCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new P&ID"""
    # Verify project exists
    result = await db.execute(
        select(Project).where(Project.id == pid_data.project_id)
    )
    project = result.scalar_one_or_none()

    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found"
        )

    pid = PID(
        project_id=pid_data.project_id,
        name=pid_data.name,
        description=pid_data.description,
    )

    db.add(pid)
    await db.commit()
    await db.refresh(pid)

    return pid


@router.get("/", response_model=List[PIDResponse])
async def list_pids(
    project_id: UUID = None,
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """List P&IDs, optionally filtered by project"""
    query = select(PID)

    if project_id:
        query = query.where(PID.project_id == project_id)

    query = query.offset(skip).limit(limit).order_by(PID.updated_at.desc())

    result = await db.execute(query)
    pids = result.scalars().all()
    return pids


@router.get("/{pid_id}", response_model=PIDResponse)
async def get_pid(
    pid_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get a specific P&ID"""
    result = await db.execute(
        select(PID).where(PID.id == pid_id)
    )
    pid = result.scalar_one_or_none()

    if not pid:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="P&ID not found"
        )

    return pid


@router.patch("/{pid_id}", response_model=PIDResponse)
async def update_pid(
    pid_id: UUID,
    pid_data: PIDUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update a P&ID"""
    result = await db.execute(
        select(PID).where(PID.id == pid_id)
    )
    pid = result.scalar_one_or_none()

    if not pid:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="P&ID not found"
        )

    # Update fields
    update_data = pid_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(pid, field, value)

    await db.commit()
    await db.refresh(pid)

    return pid


@router.delete("/{pid_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_pid(
    pid_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete a P&ID"""
    result = await db.execute(
        select(PID).where(PID.id == pid_id)
    )
    pid = result.scalar_one_or_none()

    if not pid:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="P&ID not found"
        )

    await db.delete(pid)
    await db.commit()

    return None
