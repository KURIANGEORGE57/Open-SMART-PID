"""
Process Analyzer Agent

Analyzes process description and extracts key information
"""
from typing import Dict, Any, List
import re

from app.agents.base import BaseAgent, PIDState


class ProcessAnalyzerAgent(BaseAgent):
    """
    Analyzes process description and extracts:
    - Main process operations
    - Equipment requirements
    - Fluid streams
    - Critical control requirements
    - Safety considerations
    """

    def execute(self, state: PIDState) -> PIDState:
        """Analyze process description"""
        self._log_message(state, "Starting process analysis")

        process_description = state["process_description"]

        # Extract operations (simplified - will be enhanced with LLM)
        operations = self._extract_operations(process_description)
        state["generation_metadata"]["operations"] = operations

        # Enhance equipment list with extracted info
        if not state["equipment_list"]:
            # If no equipment provided, try to extract from description
            state["equipment_list"] = self._extract_equipment(process_description)

        # Extract fluid streams
        streams = self._extract_streams(process_description)
        if not state["piping_specs"]:
            state["piping_specs"] = streams

        self._log_message(
            state,
            f"Process analysis complete: {len(state['equipment_list'])} equipment items, "
            f"{len(operations)} operations"
        )

        return state

    def _extract_operations(self, description: str) -> List[str]:
        """Extract process operations from description"""
        operations = []
        operation_keywords = [
            "heating", "cooling", "mixing", "separation", "distillation",
            "reaction", "filtration", "pumping", "compression", "storage"
        ]

        description_lower = description.lower()
        for keyword in operation_keywords:
            if keyword in description_lower:
                operations.append(keyword)

        return operations

    def _extract_equipment(self, description: str) -> List[Dict[str, Any]]:
        """Extract equipment mentions from description"""
        equipment = []
        equipment_keywords = {
            "pump": "pump",
            "tank": "tank",
            "vessel": "vessel",
            "reactor": "reactor",
            "heat exchanger": "heat_exchanger",
            "exchanger": "heat_exchanger",
            "column": "column",
            "separator": "separator",
            "filter": "filter",
            "mixer": "mixer",
            "agitator": "mixer"
        }

        description_lower = description.lower()
        tag_counter = {}

        for keyword, eq_type in equipment_keywords.items():
            if keyword in description_lower:
                # Count occurrences
                count = description_lower.count(keyword)

                if eq_type not in tag_counter:
                    tag_counter[eq_type] = 0

                for i in range(count):
                    tag_counter[eq_type] += 1
                    tag_num = tag_counter[eq_type]

                    # Generate tag (e.g., P-101 for pump)
                    prefix = eq_type[0].upper()
                    if eq_type == "heat_exchanger":
                        prefix = "E"
                    elif eq_type == "tank":
                        prefix = "T"
                    elif eq_type == "vessel":
                        prefix = "V"

                    tag = f"{prefix}-{tag_num:03d}"

                    equipment.append({
                        "tag": tag,
                        "type": eq_type,
                        "description": f"{keyword.title()}",
                        "properties": {},
                        "extracted": True
                    })

        return equipment

    def _extract_streams(self, description: str) -> List[Dict[str, Any]]:
        """Extract fluid stream information"""
        streams = []

        # Look for fluid mentions
        fluid_keywords = [
            "water", "oil", "gas", "steam", "air",
            "product", "feed", "coolant", "refrigerant"
        ]

        description_lower = description.lower()
        for fluid in fluid_keywords:
            if fluid in description_lower:
                streams.append({
                    "fluid_service": fluid.title(),
                    "line_type": "process",
                    "extracted": True
                })

        return streams
