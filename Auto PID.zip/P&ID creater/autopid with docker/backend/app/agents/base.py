"""
Base agent class and state definitions
"""
from typing import TypedDict, List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID


class PIDState(TypedDict):
    """State passed between agents"""
    # Input data
    project_id: UUID
    user_requirements: Dict[str, Any]
    process_description: str

    # Extracted data
    equipment_list: List[Dict[str, Any]]
    piping_specs: List[Dict[str, Any]]
    instrumentation: List[Dict[str, Any]]

    # Layout and design
    layout_plan: Dict[str, Any]
    connections: List[Dict[str, Any]]

    # Validation and metadata
    validation_results: Dict[str, Any]
    generation_metadata: Dict[str, Any]

    # Final output
    generated_pid: Dict[str, Any]

    # Agent communication
    messages: List[Dict[str, str]]
    iteration_count: int
    status: str
    errors: List[str]


@dataclass
class AgentMessage:
    """Message passed between agents"""
    sender: str
    receiver: str
    message_type: str  # query, response, action, feedback
    content: Dict[str, Any]
    context: Dict[str, Any]
    timestamp: datetime


class BaseAgent:
    """Base class for all agents"""

    def __init__(self, name: str, llm_provider: Optional[Any] = None):
        self.name = name
        self.llm_provider = llm_provider

    def execute(self, state: PIDState) -> PIDState:
        """
        Execute the agent's main logic

        Args:
            state: Current PID state

        Returns:
            Updated PID state
        """
        raise NotImplementedError("Subclasses must implement execute method")

    def _log_message(self, state: PIDState, message: str, level: str = "info"):
        """Add a message to the state log"""
        state["messages"].append({
            "agent": self.name,
            "message": message,
            "level": level,
            "timestamp": datetime.utcnow().isoformat()
        })
        return state

    def _get_llm_response(self, prompt: str, **kwargs) -> str:
        """
        Get response from LLM

        This is a placeholder that will be replaced with actual LLM integration
        """
        if self.llm_provider:
            # TODO: Implement actual LLM call
            return f"Mock LLM response for: {prompt[:50]}..."
        return "LLM not configured"
