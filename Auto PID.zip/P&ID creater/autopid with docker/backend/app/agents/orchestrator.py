"""
Orchestrator agent - coordinates all other agents
"""
from typing import Dict, Any, List
from uuid import UUID
import logging

from app.agents.base import BaseAgent, PIDState
from app.agents.process_analyzer import ProcessAnalyzerAgent
from app.agents.equipment_designer import EquipmentDesignerAgent
from app.agents.layout_optimizer import LayoutOptimizerAgent

logger = logging.getLogger(__name__)


class PIDOrchestrator:
    """
    Main orchestrator for P&ID generation

    Coordinates multiple agents to generate a complete P&ID
    """

    def __init__(self):
        # Initialize agents
        self.process_analyzer = ProcessAnalyzerAgent("ProcessAnalyzer")
        self.equipment_designer = EquipmentDesignerAgent("EquipmentDesigner")
        self.layout_optimizer = LayoutOptimizerAgent("LayoutOptimizer")
        # TODO: Add more agents (instrumentation, validation, etc.)

    async def generate_pid(
        self,
        project_id: UUID,
        wizard_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate P&ID from wizard data

        Args:
            project_id: Project UUID
            wizard_data: Data from wizard interface

        Returns:
            Generated P&ID data
        """
        logger.info(f"Starting P&ID generation for project {project_id}")

        # Initialize state
        state: PIDState = {
            "project_id": project_id,
            "user_requirements": wizard_data,
            "process_description": wizard_data.get("process_description", {}).get("narrative", ""),
            "equipment_list": wizard_data.get("equipment", []),
            "piping_specs": wizard_data.get("piping", []),
            "instrumentation": wizard_data.get("instrumentation", []),
            "layout_plan": {},
            "connections": [],
            "validation_results": {},
            "generation_metadata": {
                "started_at": "",
                "agents_used": []
            },
            "generated_pid": {},
            "messages": [],
            "iteration_count": 0,
            "status": "initializing",
            "errors": []
        }

        try:
            # Step 1: Analyze process description
            logger.info("Step 1: Analyzing process description")
            state["status"] = "analyzing_process"
            state = self.process_analyzer.execute(state)

            # Step 2: Design equipment layout
            logger.info("Step 2: Designing equipment layout")
            state["status"] = "designing_equipment"
            state = self.equipment_designer.execute(state)

            # Step 3: Optimize layout
            logger.info("Step 3: Optimizing layout")
            state["status"] = "optimizing_layout"
            state = self.layout_optimizer.execute(state)

            # Step 4: Generate final P&ID structure
            logger.info("Step 4: Generating final P&ID")
            state["status"] = "generating_output"
            state = self._generate_final_output(state)

            state["status"] = "completed"
            logger.info("P&ID generation completed successfully")

        except Exception as e:
            logger.error(f"Error during P&ID generation: {e}")
            state["status"] = "failed"
            state["errors"].append(str(e))

        return state["generated_pid"]

    def _generate_final_output(self, state: PIDState) -> PIDState:
        """Generate final P&ID output structure"""
        generated_pid = {
            "canvas_data": {
                "components": state["equipment_list"],
                "connections": state["connections"],
                "layout": state["layout_plan"]
            },
            "metadata": {
                "generation_date": "",
                "agents_used": state["generation_metadata"].get("agents_used", []),
                "messages": state["messages"]
            }
        }

        state["generated_pid"] = generated_pid
        return state
