/**
 * Wizard state management using Zustand
 */
import { create } from 'zustand'
import { ProjectCreate, IndustryType, StandardType } from '../types/project'
import { WizardData, ProcessDescription, EquipmentSpec, PipingSpec, InstrumentSpec } from '../types/wizard'

interface WizardState {
  // Current step (0-4)
  currentStep: number

  // Wizard data
  projectInfo: ProjectCreate | null
  processDescription: ProcessDescription | null
  equipment: EquipmentSpec[]
  piping: PipingSpec[]
  instrumentation: InstrumentSpec[]

  // UI state
  isGenerating: boolean
  generationProgress: number
  generationTaskId: string | null

  // Actions
  setCurrentStep: (step: number) => void
  nextStep: () => void
  previousStep: () => void

  setProjectInfo: (info: ProjectCreate) => void
  setProcessDescription: (desc: ProcessDescription) => void
  setEquipment: (equipment: EquipmentSpec[]) => void
  addEquipment: (eq: EquipmentSpec) => void
  removeEquipment: (tag: string) => void
  setPiping: (piping: PipingSpec[]) => void
  addPiping: (pipe: PipingSpec) => void
  removePiping: (index: number) => void
  setInstrumentation: (instruments: InstrumentSpec[]) => void
  addInstrument: (inst: InstrumentSpec) => void
  removeInstrument: (tag: string) => void

  setGenerating: (isGenerating: boolean) => void
  setGenerationProgress: (progress: number) => void
  setGenerationTaskId: (taskId: string | null) => void

  // Get complete wizard data
  getWizardData: () => WizardData | null

  // Reset wizard
  reset: () => void
}

const initialState = {
  currentStep: 0,
  projectInfo: null,
  processDescription: null,
  equipment: [],
  piping: [],
  instrumentation: [],
  isGenerating: false,
  generationProgress: 0,
  generationTaskId: null,
}

export const useWizardStore = create<WizardState>((set, get) => ({
  ...initialState,

  setCurrentStep: (step) => set({ currentStep: step }),

  nextStep: () => set((state) => ({
    currentStep: Math.min(state.currentStep + 1, 4)
  })),

  previousStep: () => set((state) => ({
    currentStep: Math.max(state.currentStep - 1, 0)
  })),

  setProjectInfo: (info) => set({ projectInfo: info }),

  setProcessDescription: (desc) => set({ processDescription: desc }),

  setEquipment: (equipment) => set({ equipment }),

  addEquipment: (eq) => set((state) => ({
    equipment: [...state.equipment, eq]
  })),

  removeEquipment: (tag) => set((state) => ({
    equipment: state.equipment.filter(eq => eq.tag !== tag)
  })),

  setPiping: (piping) => set({ piping }),

  addPiping: (pipe) => set((state) => ({
    piping: [...state.piping, pipe]
  })),

  removePiping: (index) => set((state) => ({
    piping: state.piping.filter((_, i) => i !== index)
  })),

  setInstrumentation: (instruments) => set({ instrumentation: instruments }),

  addInstrument: (inst) => set((state) => ({
    instrumentation: [...state.instrumentation, inst]
  })),

  removeInstrument: (tag) => set((state) => ({
    instrumentation: state.instrumentation.filter(inst => inst.tag !== tag)
  })),

  setGenerating: (isGenerating) => set({ isGenerating }),

  setGenerationProgress: (progress) => set({ generationProgress: progress }),

  setGenerationTaskId: (taskId) => set({ generationTaskId: taskId }),

  getWizardData: () => {
    const state = get()
    if (!state.projectInfo) return null

    return {
      project_info: state.projectInfo,
      process_description: state.processDescription || {
        narrative: '',
        safety_requirements: []
      },
      equipment: state.equipment,
      piping: state.piping,
      instrumentation: state.instrumentation
    }
  },

  reset: () => set(initialState)
}))
