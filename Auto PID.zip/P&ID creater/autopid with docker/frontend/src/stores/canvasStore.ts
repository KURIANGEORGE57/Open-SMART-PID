/**
 * Canvas state management using Zustand
 */
import { create } from 'zustand'
import { CanvasComponent, Connection, Position, CanvasState } from '../types/component'

interface CanvasStore extends CanvasState {
  // Component actions
  addComponent: (component: CanvasComponent) => void
  updateComponent: (id: string, updates: Partial<CanvasComponent>) => void
  removeComponent: (id: string) => void
  moveComponent: (id: string, position: Position) => void

  // Connection actions
  addConnection: (connection: Connection) => void
  updateConnection: (id: string, updates: Partial<Connection>) => void
  removeConnection: (id: string) => void

  // Selection
  selectComponent: (id: string | null) => void
  getSelectedComponent: () => CanvasComponent | null

  // View controls
  setZoom: (zoom: number) => void
  zoomIn: () => void
  zoomOut: () => void
  resetZoom: () => void
  setPan: (pan: Position) => void

  // Canvas operations
  loadCanvas: (data: { components: CanvasComponent[], connections: Connection[] }) => void
  clearCanvas: () => void
  exportCanvas: () => { components: CanvasComponent[], connections: Connection[] }
}

const initialState: CanvasState = {
  components: [],
  connections: [],
  selectedId: null,
  zoom: 1,
  pan: { x: 0, y: 0 }
}

export const useCanvasStore = create<CanvasStore>((set, get) => ({
  ...initialState,

  // Component actions
  addComponent: (component) => set((state) => ({
    components: [...state.components, component]
  })),

  updateComponent: (id, updates) => set((state) => ({
    components: state.components.map(c =>
      c.id === id ? { ...c, ...updates } : c
    )
  })),

  removeComponent: (id) => set((state) => ({
    components: state.components.filter(c => c.id !== id),
    connections: state.connections.filter(
      conn => conn.from_component_id !== id && conn.to_component_id !== id
    ),
    selectedId: state.selectedId === id ? null : state.selectedId
  })),

  moveComponent: (id, position) => set((state) => ({
    components: state.components.map(c =>
      c.id === id ? { ...c, position } : c
    )
  })),

  // Connection actions
  addConnection: (connection) => set((state) => ({
    connections: [...state.connections, connection]
  })),

  updateConnection: (id, updates) => set((state) => ({
    connections: state.connections.map(conn =>
      conn.id === id ? { ...conn, ...updates } : conn
    )
  })),

  removeConnection: (id) => set((state) => ({
    connections: state.connections.filter(conn => conn.id !== id),
    selectedId: state.selectedId === id ? null : state.selectedId
  })),

  // Selection
  selectComponent: (id) => set({ selectedId: id }),

  getSelectedComponent: () => {
    const state = get()
    if (!state.selectedId) return null
    return state.components.find(c => c.id === state.selectedId) || null
  },

  // View controls
  setZoom: (zoom) => set({ zoom: Math.max(0.1, Math.min(5, zoom)) }),

  zoomIn: () => set((state) => ({
    zoom: Math.min(5, state.zoom * 1.2)
  })),

  zoomOut: () => set((state) => ({
    zoom: Math.max(0.1, state.zoom / 1.2)
  })),

  resetZoom: () => set({ zoom: 1, pan: { x: 0, y: 0 } }),

  setPan: (pan) => set({ pan }),

  // Canvas operations
  loadCanvas: (data) => set({
    components: data.components,
    connections: data.connections,
    selectedId: null
  }),

  clearCanvas: () => set(initialState),

  exportCanvas: () => {
    const state = get()
    return {
      components: state.components,
      connections: state.connections
    }
  }
}))
