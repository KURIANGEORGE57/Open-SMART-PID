/**
 * Project service - API calls for projects
 */
import api from './api'
import { Project, ProjectCreate } from '../types/project'

export const projectService = {
  // List all projects
  async list(skip = 0, limit = 100): Promise<Project[]> {
    const response = await api.get('/projects', {
      params: { skip, limit }
    })
    return response.data
  },

  // Get single project
  async get(id: string): Promise<Project> {
    const response = await api.get(`/projects/${id}`)
    return response.data
  },

  // Create project
  async create(data: ProjectCreate): Promise<Project> {
    const response = await api.post('/projects', data)
    return response.data
  },

  // Update project
  async update(id: string, data: Partial<ProjectCreate>): Promise<Project> {
    const response = await api.patch(`/projects/${id}`, data)
    return response.data
  },

  // Delete project
  async delete(id: string): Promise<void> {
    await api.delete(`/projects/${id}`)
  }
}
