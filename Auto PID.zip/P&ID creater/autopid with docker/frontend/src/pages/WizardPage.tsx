import WizardContainer from '../components/Wizard/WizardContainer'

export default function WizardPage() {
  return <WizardContainer />
}
