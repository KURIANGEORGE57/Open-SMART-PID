/**
 * Connections Tab - Shows incoming/outgoing connections
 */
import React from 'react'
import { useCanvasStore } from '../../stores/canvasStore'

interface ConnectionsTabProps {
  componentId: string
}

export const ConnectionsTab: React.FC<ConnectionsTabProps> = ({ componentId }) => {
  const { connections, components } = useCanvasStore()

  const incomingConnections = connections.filter(
    conn => conn.to_component_id === componentId
  )

  const outgoingConnections = connections.filter(
    conn => conn.from_component_id === componentId
  )

  const getComponentTag = (id: string) => {
    const comp = components.find(c => c.id === id)
    return comp?.tag || 'Unknown'
  }

  return (
    <div className="p-4 space-y-4">
      {/* Incoming */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-2">
          Incoming ({incomingConnections.length})
        </h3>
        {incomingConnections.length === 0 ? (
          <p className="text-sm text-gray-500">No incoming connections</p>
        ) : (
          <div className="space-y-2">
            {incomingConnections.map(conn => (
              <div
                key={conn.id}
                className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">
                    {conn.line_number || 'Unnamed'}
                  </span>
                  <span className="text-xs text-gray-500 capitalize">
                    {conn.line_type}
                  </span>
                </div>
                <div className="text-xs text-gray-600">
                  From: <span className="font-mono">{getComponentTag(conn.from_component_id)}</span>
                </div>
                {conn.fluid_service && (
                  <div className="text-xs text-gray-600">
                    Service: {conn.fluid_service}
                  </div>
                )}
                {conn.line_size && (
                  <div className="text-xs text-gray-600">
                    Size: {conn.line_size}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Outgoing */}
      <div>
        <h3 className="text-sm font-semibold text-gray-900 mb-2">
          Outgoing ({outgoingConnections.length})
        </h3>
        {outgoingConnections.length === 0 ? (
          <p className="text-sm text-gray-500">No outgoing connections</p>
        ) : (
          <div className="space-y-2">
            {outgoingConnections.map(conn => (
              <div
                key={conn.id}
                className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">
                    {conn.line_number || 'Unnamed'}
                  </span>
                  <span className="text-xs text-gray-500 capitalize">
                    {conn.line_type}
                  </span>
                </div>
                <div className="text-xs text-gray-600">
                  To: <span className="font-mono">{getComponentTag(conn.to_component_id)}</span>
                </div>
                {conn.fluid_service && (
                  <div className="text-xs text-gray-600">
                    Service: {conn.fluid_service}
                  </div>
                )}
                {conn.line_size && (
                  <div className="text-xs text-gray-600">
                    Size: {conn.line_size}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Connection Button */}
      <button className="w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-800">
        + Add Connection
      </button>
    </div>
  )
}
