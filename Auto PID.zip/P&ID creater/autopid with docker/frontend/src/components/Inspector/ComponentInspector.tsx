/**
 * Component Inspector Panel
 */
import React, { useState } from 'react'
import { useCanvasStore } from '../../stores/canvasStore'
import { PropertiesTab } from './PropertiesTab'
import { ConnectionsTab } from './ConnectionsTab'
import { NotesTab } from './NotesTab'

type TabType = 'properties' | 'connections' | 'notes'

export const ComponentInspector: React.FC = () => {
  const { getSelectedComponent, selectedId } = useCanvasStore()
  const [activeTab, setActiveTab] = useState<TabType>('properties')

  const selectedComponent = getSelectedComponent()

  if (!selectedComponent) {
    return (
      <div className="w-80 bg-white border-l border-gray-200 p-6 flex items-center justify-center">
        <div className="text-center text-gray-500">
          <div className="text-4xl mb-4">🔍</div>
          <p className="text-sm">Select a component to view properties</p>
        </div>
      </div>
    )
  }

  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: 'properties', label: 'Properties', icon: '⚙️' },
    { id: 'connections', label: 'Connections', icon: '🔗' },
    { id: 'notes', label: 'Notes', icon: '📝' },
  ]

  return (
    <div className="w-80 bg-white border-l border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold text-gray-900">
            {selectedComponent.tag}
          </h2>
          <button
            onClick={() => useCanvasStore.getState().selectComponent(null)}
            className="text-gray-400 hover:text-gray-600"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <p className="text-sm text-gray-600 capitalize">
          {selectedComponent.category} • {selectedComponent.component_type.replace('_', ' ')}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 px-4 py-3 text-sm font-medium ${
              activeTab === tab.id
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <span className="mr-1">{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === 'properties' && (
          <PropertiesTab component={selectedComponent} />
        )}
        {activeTab === 'connections' && (
          <ConnectionsTab componentId={selectedComponent.id} />
        )}
        {activeTab === 'notes' && (
          <NotesTab component={selectedComponent} />
        )}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-gray-200 flex gap-2">
        <button
          onClick={() => {
            useCanvasStore.getState().removeComponent(selectedComponent.id)
          }}
          className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Delete
        </button>
        <button
          onClick={() => {
            // TODO: Implement duplicate
            console.log('Duplicate component')
          }}
          className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
        >
          Duplicate
        </button>
      </div>
    </div>
  )
}
