/**
 * Main Wizard Container Component
 */
import { useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useWizardStore } from '../../stores/wizardStore'
import ProjectInfoStep from './ProjectInfoStep'
import ProcessDescriptionStep from './ProcessDescriptionStep'
import EquipmentStep from './EquipmentStep'
import ReviewStep from './ReviewStep'

const steps = [
  { title: 'Project Info', component: ProjectInfoStep },
  { title: 'Process Description', component: ProcessDescriptionStep },
  { title: 'Equipment', component: EquipmentStep },
  { title: 'Review & Generate', component: ReviewStep },
]

export default function WizardContainer() {
  const { projectId } = useParams()
  const navigate = useNavigate()
  const { currentStep, setCurrentStep, nextStep, previousStep, reset } = useWizardStore()

  useEffect(() => {
    // Reset wizard when component mounts
    if (!projectId) {
      reset()
    }
  }, [projectId, reset])

  const CurrentStepComponent = steps[currentStep].component

  const canGoNext = currentStep < steps.length - 1
  const canGoPrevious = currentStep > 0

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">P&ID Creation Wizard</h1>
              <p className="text-gray-600 mt-1">
                Step {currentStep + 1} of {steps.length}: {steps[currentStep].title}
              </p>
            </div>
            <button
              onClick={() => navigate('/projects')}
              className="px-4 py-2 text-gray-600 hover:text-gray-900"
            >
              Cancel
            </button>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-8">
          {steps.map((step, index) => (
            <div key={index} className="flex-1">
              <div className="flex items-center">
                <div
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors ${
                    index === currentStep
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : index < currentStep
                      ? 'border-green-600 bg-green-600 text-white'
                      : 'border-gray-300 bg-white text-gray-400'
                  }`}
                >
                  {index < currentStep ? (
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ) : (
                    <span>{index + 1}</span>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-2 transition-colors ${
                      index < currentStep ? 'bg-green-600' : 'bg-gray-300'
                    }`}
                  />
                )}
              </div>
              <div className="mt-2 text-sm font-medium text-gray-700">{step.title}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow p-8">
          <CurrentStepComponent />
        </div>

        {/* Navigation Buttons */}
        <div className="mt-8 flex justify-between">
          <button
            onClick={previousStep}
            disabled={!canGoPrevious}
            className={`px-6 py-3 rounded-lg font-semibold ${
              canGoPrevious
                ? 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            Previous
          </button>

          {canGoNext && (
            <button
              onClick={nextStep}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
            >
              Next
            </button>
          )}
        </div>
      </main>
    </div>
  )
}
