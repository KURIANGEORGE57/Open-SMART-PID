/**
 * Step 3: Equipment Specification
 */
import { useState } from 'react'
import { useWizardStore } from '../../stores/wizardStore'
import { wizardService } from '../../services/wizardService'
import { EquipmentSpec } from '../../types/wizard'

export default function EquipmentStep() {
  const { equipment, processDescription, setEquipment, addEquipment, removeEquipment } = useWizardStore()
  const [isExtracting, setIsExtracting] = useState(false)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newEquipment, setNewEquipment] = useState<Partial<EquipmentSpec>>({
    tag: '',
    type: 'pump',
    description: '',
    properties: {}
  })

  const handleExtract = async () => {
    if (!processDescription?.narrative) return

    setIsExtracting(true)
    try {
      const extracted = await wizardService.extractEquipment(processDescription.narrative)
      setEquipment(extracted)
    } catch (error) {
      console.error('Failed to extract equipment:', error)
    } finally {
      setIsExtracting(false)
    }
  }

  const handleAddEquipment = () => {
    if (newEquipment.tag && newEquipment.type && newEquipment.description) {
      addEquipment({
        tag: newEquipment.tag,
        type: newEquipment.type,
        description: newEquipment.description,
        properties: newEquipment.properties || {}
      })
      setNewEquipment({ tag: '', type: 'pump', description: '', properties: {} })
      setShowAddForm(false)
    }
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Equipment Specification</h2>

      {/* Extract Equipment Button */}
      <div className="mb-6">
        <button
          onClick={handleExtract}
          disabled={isExtracting || !processDescription?.narrative}
          className="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
        >
          {isExtracting ? (
            <>
              <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              Extracting...
            </>
          ) : (
            <>🤖 Auto-Extract Equipment from Description</>
          )}
        </button>
        <p className="mt-2 text-sm text-gray-600">
          AI will analyze your process description and suggest equipment
        </p>
      </div>

      {/* Equipment Table */}
      {equipment.length > 0 && (
        <div className="mb-6 border rounded-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Tag</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Type</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Description</th>
                <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {equipment.map((eq, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-mono">{eq.tag}</td>
                  <td className="px-4 py-3 text-sm">{eq.type}</td>
                  <td className="px-4 py-3 text-sm">{eq.description}</td>
                  <td className="px-4 py-3 text-sm text-right">
                    <button
                      onClick={() => removeEquipment(eq.tag)}
                      className="text-red-600 hover:text-red-800"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Equipment Button */}
      {!showAddForm && (
        <button
          onClick={() => setShowAddForm(true)}
          className="mb-6 px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-800 w-full"
        >
          + Add Equipment Manually
        </button>
      )}

      {/* Add Equipment Form */}
      {showAddForm && (
        <div className="mb-6 p-4 border border-gray-300 rounded-lg bg-gray-50">
          <h3 className="font-semibold text-gray-900 mb-4">Add Equipment</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tag</label>
              <input
                type="text"
                value={newEquipment.tag}
                onChange={(e) => setNewEquipment({ ...newEquipment, tag: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                placeholder="e.g., P-101"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
              <select
                value={newEquipment.type}
                onChange={(e) => setNewEquipment({ ...newEquipment, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="pump">Pump</option>
                <option value="tank">Tank</option>
                <option value="vessel">Vessel</option>
                <option value="reactor">Reactor</option>
                <option value="heat_exchanger">Heat Exchanger</option>
                <option value="column">Column</option>
                <option value="filter">Filter</option>
                <option value="mixer">Mixer</option>
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <input
                type="text"
                value={newEquipment.description}
                onChange={(e) => setNewEquipment({ ...newEquipment, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                placeholder="e.g., Feed Pump"
              />
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button
              onClick={handleAddEquipment}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Add
            </button>
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-semibold text-blue-900 mb-2">💡 Tip</h3>
        <p className="text-sm text-blue-800">
          Use standard tag numbering (e.g., P-101, T-201, E-301). You can always edit or add more
          details after P&ID generation.
        </p>
      </div>
    </div>
  )
}
