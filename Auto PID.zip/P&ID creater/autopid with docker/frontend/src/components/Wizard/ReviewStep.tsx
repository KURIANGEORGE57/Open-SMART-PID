/**
 * Step 4: Review & Generate
 */
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useWizardStore } from '../../stores/wizardStore'
import { projectService } from '../../services/projectService'
import { wizardService } from '../../services/wizardService'

export default function ReviewStep() {
  const navigate = useNavigate()
  const {
    projectInfo,
    processDescription,
    equipment,
    piping,
    instrumentation,
    isGenerating,
    generationProgress,
    generationTaskId,
    setGenerating,
    setGenerationProgress,
    setGenerationTaskId,
    getWizardData
  } = useWizardStore()

  const [projectId, setProjectId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [currentStep, setCurrentStep] = useState('')

  const handleGenerate = async () => {
    if (!projectInfo) return

    setError(null)
    setGenerating(true)
    setGenerationProgress(0)

    try {
      // Step 1: Create project
      setCurrentStep('Creating project...')
      setGenerationProgress(10)
      const project = await projectService.create(projectInfo)
      setProjectId(project.id)

      // Step 2: Start generation
      setCurrentStep('Starting P&ID generation...')
      setGenerationProgress(20)
      const wizardData = getWizardData()
      if (!wizardData) throw new Error('Invalid wizard data')

      const response = await wizardService.generate(project.id, wizardData)
      setGenerationTaskId(response.task_id)

      // Step 3: Poll for status
      pollGenerationStatus(response.task_id)

    } catch (err: any) {
      setError(err.response?.data?.detail || err.message || 'Generation failed')
      setGenerating(false)
    }
  }

  const pollGenerationStatus = async (taskId: string) => {
    const pollInterval = setInterval(async () => {
      try {
        const status = await wizardService.getStatus(taskId)

        setGenerationProgress(status.progress)
        setCurrentStep(status.current_step)

        if (status.status === 'completed' && status.pid_id) {
          clearInterval(pollInterval)
          setGenerating(false)
          // Navigate to editor
          setTimeout(() => {
            navigate(`/editor/${status.pid_id}`)
          }, 1000)
        } else if (status.status === 'failed') {
          clearInterval(pollInterval)
          setError(status.error || 'Generation failed')
          setGenerating(false)
        }
      } catch (err) {
        clearInterval(pollInterval)
        setError('Failed to get generation status')
        setGenerating(false)
      }
    }, 2000) // Poll every 2 seconds
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Review & Generate</h2>

      {/* Summary */}
      <div className="space-y-6 mb-8">
        {/* Project Info */}
        <div className="border rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-3">Project Information</h3>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <dt className="text-gray-600">Name:</dt>
            <dd className="font-medium">{projectInfo?.name}</dd>
            <dt className="text-gray-600">Industry:</dt>
            <dd>{projectInfo?.industry_type}</dd>
            <dt className="text-gray-600">Standard:</dt>
            <dd>{projectInfo?.standard}</dd>
          </dl>
        </div>

        {/* Process Description */}
        <div className="border rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-3">Process Description</h3>
          <p className="text-sm text-gray-700 whitespace-pre-line">
            {processDescription?.narrative || 'No description provided'}
          </p>
        </div>

        {/* Equipment */}
        <div className="border rounded-lg p-4">
          <h3 className="font-semibold text-gray-900 mb-3">
            Equipment ({equipment.length} items)
          </h3>
          {equipment.length > 0 ? (
            <ul className="text-sm space-y-1">
              {equipment.map((eq, index) => (
                <li key={index} className="flex justify-between">
                  <span className="font-mono">{eq.tag}</span>
                  <span className="text-gray-600">{eq.description}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500">No equipment specified</p>
          )}
        </div>
      </div>

      {/* Generation Progress */}
      {isGenerating && (
        <div className="mb-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-4">Generating P&ID...</h3>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-blue-800">{currentStep}</span>
              <span className="text-sm font-semibold text-blue-900">{generationProgress}%</span>
            </div>
            <div className="w-full bg-blue-200 rounded-full h-3 overflow-hidden">
              <div
                className="bg-blue-600 h-full transition-all duration-500"
                style={{ width: `${generationProgress}%` }}
              />
            </div>
          </div>

          <p className="text-sm text-blue-800">
            This may take 30-60 seconds. Please don't close this page.
          </p>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-lg">
          <h3 className="font-semibold text-red-900 mb-2">Error</h3>
          <p className="text-sm text-red-800">{error}</p>
        </div>
      )}

      {/* Generate Button */}
      {!isGenerating && !generationTaskId && (
        <button
          onClick={handleGenerate}
          disabled={!projectInfo || equipment.length === 0}
          className="w-full px-8 py-4 bg-green-600 text-white rounded-lg font-semibold text-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          🚀 Generate Smart P&ID
        </button>
      )}

      <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <h3 className="font-semibold text-yellow-900 mb-2">⚡ What happens next?</h3>
        <ul className="text-sm text-yellow-800 space-y-1">
          <li>• AI agents will analyze your requirements</li>
          <li>• Equipment will be positioned optimally</li>
          <li>• Connections will be created automatically</li>
          <li>• You'll be able to edit and refine the result</li>
        </ul>
      </div>
    </div>
  )
}
