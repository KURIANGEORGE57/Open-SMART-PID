/**
 * Symbol library - SVG components for P&ID symbols
 */
import React from 'react'
import { Group, Circle, Rect, Line, Path, Text, Ellipse } from 'react-konva'

interface SymbolProps {
  x?: number
  y?: number
  scale?: number
  rotation?: number
  fill?: string
  stroke?: string
}

// Equipment Symbols

export const TankSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, fill = '#fff', stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Rect
      width={60}
      height={80}
      fill={fill}
      stroke={stroke}
      strokeWidth={2}
    />
    <Line
      points={[0, 10, 60, 10]}
      stroke={stroke}
      strokeWidth={2}
    />
  </Group>
)

export const PumpSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, fill = '#fff', stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Circle
      radius={25}
      x={25}
      y={25}
      fill={fill}
      stroke={stroke}
      strokeWidth={2}
    />
    <Path
      data="M 15 25 L 35 15 L 35 35 Z"
      fill={stroke}
    />
  </Group>
)

export const HeatExchangerSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, fill = '#fff', stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Circle
      radius={30}
      x={30}
      y={30}
      fill={fill}
      stroke={stroke}
      strokeWidth={2}
    />
    <Line points={[15, 15, 45, 45]} stroke={stroke} strokeWidth={2} />
    <Line points={[45, 15, 15, 45]} stroke={stroke} strokeWidth={2} />
  </Group>
)

export const ReactorSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, fill = '#fff', stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Ellipse
      radiusX={30}
      radiusY={45}
      x={30}
      y={50}
      fill={fill}
      stroke={stroke}
      strokeWidth={2}
    />
    <Rect
      x={25}
      y={5}
      width={10}
      height={15}
      fill={fill}
      stroke={stroke}
      strokeWidth={2}
    />
  </Group>
)

export const ColumnSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, fill = '#fff', stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Rect
      width={40}
      height={100}
      fill={fill}
      stroke={stroke}
      strokeWidth={2}
    />
    {[20, 40, 60, 80].map((yPos, i) => (
      <Line
        key={i}
        points={[0, yPos, 40, yPos]}
        stroke={stroke}
        strokeWidth={1}
      />
    ))}
  </Group>
)

// Valve Symbols

export const GateValveSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Path
      data="M 10 0 L 20 15 L 0 15 Z"
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Path
      data="M 10 30 L 20 15 L 0 15 Z"
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Line points={[10, 0, 10, 30]} stroke={stroke} strokeWidth={2} />
  </Group>
)

export const BallValveSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Circle
      radius={12}
      x={12}
      y={15}
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Line points={[12, 3, 12, 27]} stroke={stroke} strokeWidth={3} />
  </Group>
)

export const CheckValveSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Path
      data="M 0 0 L 15 15 L 0 30 Z"
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Path
      data="M 15 15 L 30 0 L 30 30 Z"
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
  </Group>
)

export const ControlValveSymbol: React.FC<SymbolProps> = ({
  x = 0, y = 0, scale = 1, rotation = 0, stroke = '#000'
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Path
      data="M 10 0 L 20 15 L 0 15 Z"
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Path
      data="M 10 30 L 20 15 L 0 15 Z"
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Rect
      x={5}
      y={-15}
      width={10}
      height={15}
      stroke={stroke}
      strokeWidth={1}
      fill="#fff"
    />
  </Group>
)

// Instrument Symbols

export const InstrumentSymbol: React.FC<SymbolProps & { label?: string }> = ({
  x = 0, y = 0, scale = 1, rotation = 0, stroke = '#000', label = ''
}) => (
  <Group x={x} y={y} scaleX={scale} scaleY={scale} rotation={rotation}>
    <Circle
      radius={20}
      x={20}
      y={20}
      stroke={stroke}
      strokeWidth={2}
      fill="#fff"
    />
    <Text
      text={label}
      x={8}
      y={13}
      fontSize={14}
      fill={stroke}
      fontFamily="Arial"
      fontStyle="bold"
    />
  </Group>
)

// Utility function to get symbol component by type
export const getSymbolComponent = (type: string) => {
  const symbolMap: Record<string, React.FC<SymbolProps>> = {
    tank: TankSymbol,
    pump: PumpSymbol,
    heat_exchanger: HeatExchangerSymbol,
    reactor: ReactorSymbol,
    column: ColumnSymbol,
    gate_valve: GateValveSymbol,
    ball_valve: BallValveSymbol,
    check_valve: CheckValveSymbol,
    control_valve: ControlValveSymbol,
  }

  return symbolMap[type] || TankSymbol
}

// Symbol dimensions for layout calculations
export const getSymbolDimensions = (type: string) => {
  const dimensions: Record<string, { width: number, height: number }> = {
    tank: { width: 60, height: 80 },
    pump: { width: 50, height: 50 },
    heat_exchanger: { width: 60, height: 60 },
    reactor: { width: 60, height: 100 },
    column: { width: 40, height: 100 },
    gate_valve: { width: 20, height: 30 },
    ball_valve: { width: 24, height: 30 },
    check_valve: { width: 30, height: 30 },
    control_valve: { width: 20, height: 45 },
  }

  return dimensions[type] || { width: 50, height: 50 }
}
