/**
 * Main P&ID Canvas Component
 */
import React, { useRef, useEffect } from 'react'
import { Stage, Layer } from 'react-konva'
import { useCanvasStore } from '../../stores/canvasStore'
import { ComponentRenderer } from './ComponentRenderer'
import { ConnectionRenderer } from './ConnectionRenderer'
import { GridLayer } from './GridLayer'

interface PIDCanvasProps {
  width?: number
  height?: number
  showGrid?: boolean
}

export const PIDCanvas: React.FC<PIDCanvasProps> = ({
  width = window.innerWidth - 320, // Account for inspector panel
  height = window.innerHeight - 64, // Account for header
  showGrid = true
}) => {
  const stageRef = useRef<any>(null)

  const {
    components,
    connections,
    selectedId,
    zoom,
    pan,
    selectComponent,
    moveComponent,
    setPan
  } = useCanvasStore()

  // Handle component drag end
  const handleComponentDragEnd = (componentId: string, e: any) => {
    const node = e.target
    moveComponent(componentId, {
      x: node.x(),
      y: node.y()
    })
  }

  // Handle canvas click (deselect)
  const handleStageClick = (e: any) => {
    // Check if click was on empty area
    if (e.target === e.target.getStage()) {
      selectComponent(null)
    }
  }

  // Handle mouse wheel for zoom
  const handleWheel = (e: any) => {
    e.evt.preventDefault()

    const stage = stageRef.current
    if (!stage) return

    const oldScale = zoom
    const pointer = stage.getPointerPosition()

    const mousePointTo = {
      x: (pointer.x - pan.x) / oldScale,
      y: (pointer.y - pan.y) / oldScale,
    }

    const newScale = e.evt.deltaY > 0 ? oldScale * 0.9 : oldScale * 1.1
    const newZoom = Math.max(0.1, Math.min(5, newScale))

    useCanvasStore.setState({ zoom: newZoom })

    const newPos = {
      x: pointer.x - mousePointTo.x * newZoom,
      y: pointer.y - mousePointTo.y * newZoom,
    }

    setPan(newPos)
  }

  return (
    <div className="relative w-full h-full bg-gray-100">
      <Stage
        ref={stageRef}
        width={width}
        height={height}
        scaleX={zoom}
        scaleY={zoom}
        x={pan.x}
        y={pan.y}
        draggable
        onWheel={handleWheel}
        onClick={handleStageClick}
        onDragEnd={(e) => {
          setPan({ x: e.target.x(), y: e.target.y() })
        }}
      >
        {/* Grid Layer */}
        {showGrid && (
          <Layer listening={false}>
            <GridLayer
              width={width * 3}
              height={height * 3}
              gridSize={25}
            />
          </Layer>
        )}

        {/* Connections Layer */}
        <Layer>
          {connections.map(connection => (
            <ConnectionRenderer
              key={connection.id}
              connection={connection}
              isSelected={selectedId === connection.id}
              onSelect={() => selectComponent(connection.id)}
            />
          ))}
        </Layer>

        {/* Components Layer */}
        <Layer>
          {components.map(component => (
            <ComponentRenderer
              key={component.id}
              component={component}
              isSelected={selectedId === component.id}
              onSelect={() => selectComponent(component.id)}
              onDragEnd={(e) => handleComponentDragEnd(component.id, e)}
            />
          ))}
        </Layer>
      </Stage>

      {/* Zoom Controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2">
        <button
          onClick={() => useCanvasStore.getState().zoomIn()}
          className="w-10 h-10 bg-white rounded-lg shadow hover:bg-gray-50 flex items-center justify-center"
          title="Zoom In"
        >
          <span className="text-xl">+</span>
        </button>
        <button
          onClick={() => useCanvasStore.getState().resetZoom()}
          className="w-10 h-10 bg-white rounded-lg shadow hover:bg-gray-50 flex items-center justify-center text-xs"
          title="Reset Zoom"
        >
          {Math.round(zoom * 100)}%
        </button>
        <button
          onClick={() => useCanvasStore.getState().zoomOut()}
          className="w-10 h-10 bg-white rounded-lg shadow hover:bg-gray-50 flex items-center justify-center"
          title="Zoom Out"
        >
          <span className="text-xl">−</span>
        </button>
      </div>

      {/* Component Count */}
      <div className="absolute top-4 left-4 bg-white px-3 py-2 rounded-lg shadow text-sm">
        <span className="text-gray-600">Components:</span>{' '}
        <span className="font-semibold">{components.length}</span>
        {' | '}
        <span className="text-gray-600">Lines:</span>{' '}
        <span className="font-semibold">{connections.length}</span>
      </div>
    </div>
  )
}
