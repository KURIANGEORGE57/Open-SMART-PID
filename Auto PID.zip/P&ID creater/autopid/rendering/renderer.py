import svgwrite
from autopid.models.data_models import PIDDocument, EquipmentType
from autopid.rendering.symbols import SymbolLibrary
from autopid.knowledge.equipment_library import EquipmentLibrary

class PIDRenderer:
    def __init__(self):
        self.symbol_lib = SymbolLibrary()
        self.equip_lib = EquipmentLibrary()

    def render(self, pid_doc: PIDDocument, filename: str = "output.svg"):
        dwg = svgwrite.Drawing(filename, profile='tiny', size=('800px', '600px'))
        
        # Draw equipment
        for equip in pid_doc.equipment:
            # Determine symbol function
            symbol_key = "vessel_vertical" # Default
            
            # Simple mapping logic (can be improved)
            if equip.type == EquipmentType.PUMP:
                symbol_key = "pump_centrifugal"
            elif equip.type == EquipmentType.VESSEL:
                symbol_key = "vessel_vertical"
            elif equip.type == EquipmentType.HEAT_EXCHANGER:
                symbol_key = "heat_exchanger_st"
            elif equip.type == EquipmentType.VALVE:
                symbol_key = "valve_gate"
                
            symbol_func = self.symbol_lib.get_symbol(symbol_key)
            
            if symbol_func:
                # Use provided position or default
                pos = equip.position if equip.position else (100, 100)
                dwg.add(symbol_func(dwg, pos[0], pos[1]))
                
                # Add Tag
                dwg.add(dwg.text(equip.tag, insert=(pos[0]-15, pos[1]+40), font_size=12, fill='black'))

        # Draw streams (Simple straight lines for now)
        for stream in pid_doc.streams:
            # Find from and to equipment positions
            from_equip = next((e for e in pid_doc.equipment if e.id == stream.from_equipment), None)
            to_equip = next((e for e in pid_doc.equipment if e.id == stream.to_equipment), None)
            
            if from_equip and to_equip and from_equip.position and to_equip.position:
                dwg.add(dwg.line(start=from_equip.position, end=to_equip.position, stroke='black', stroke_width=2))
                # Add arrow at the end (simplified)
                # In a real implementation, we'd calculate the intersection with the symbol

        dwg.save()
        return filename
