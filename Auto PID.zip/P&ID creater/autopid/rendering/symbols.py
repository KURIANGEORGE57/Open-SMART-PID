import svgwrite

class SymbolLibrary:
    """ISA-5.1 compliant symbols"""
    
    @staticmethod
    def pump_centrifugal(dwg, x, y, scale=1.0):
        """SVG for centrifugal pump"""
        group = dwg.g(id='pump-centrifugal', transform=f'translate({x},{y}) scale({scale})')
        # Circle
        group.add(dwg.circle(center=(0, 0), r=20, fill='none', stroke='black', stroke_width=2))
        # Triangle
        group.add(dwg.polygon(points=[(-10, 10), (10, 10), (0, -15)], fill='black'))
        # Base
        group.add(dwg.line(start=(-20, 20), end=(20, 20), stroke='black', stroke_width=2))
        return group
    
    @staticmethod
    def vessel_vertical(dwg, x, y, scale=1.0):
        """SVG for vertical vessel"""
        group = dwg.g(id='vessel-vertical', transform=f'translate({x},{y}) scale({scale})')
        # Rectangle body
        group.add(dwg.rect(insert=(-30, -50), size=(60, 100), fill='none', stroke='black', stroke_width=2))
        # Dished heads (using paths)
        # Top head
        group.add(dwg.path(d='M -30,-50 Q 0,-70 30,-50', fill='none', stroke='black', stroke_width=2))
        # Bottom head
        group.add(dwg.path(d='M -30,50 Q 0,70 30,50', fill='none', stroke='black', stroke_width=2))
        return group

    @staticmethod
    def heat_exchanger_st(dwg, x, y, scale=1.0):
        """SVG for Shell and Tube Heat Exchanger"""
        group = dwg.g(id='heat-exchanger-st', transform=f'translate({x},{y}) scale({scale})')
        # Shell
        group.add(dwg.circle(center=(0, 0), r=30, fill='none', stroke='black', stroke_width=2))
        # Tube line
        group.add(dwg.line(start=(-40, 0), end=(40, 0), stroke='black', stroke_width=2))
        # Zigzag for tubes
        group.add(dwg.path(d='M -20,-10 L -10,10 L 0,-10 L 10,10 L 20,-10', fill='none', stroke='black', stroke_width=1))
        return group

    @staticmethod
    def valve_gate(dwg, x, y, scale=1.0):
        """SVG for Gate Valve"""
        group = dwg.g(id='valve-gate', transform=f'translate({x},{y}) scale({scale})')
        # Bowtie shape
        group.add(dwg.polygon(points=[(-10, -5), (-10, 5), (10, -5), (10, 5)], fill='none', stroke='black', stroke_width=1))
        return group

    @staticmethod
    def get_symbol(name):
        if hasattr(SymbolLibrary, name):
            return getattr(SymbolLibrary, name)
        return None
