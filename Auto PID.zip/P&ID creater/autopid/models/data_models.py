from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Literal
from enum import Enum

class EquipmentType(str, Enum):
    VESSEL = "vessel"
    PUMP = "pump"
    HEAT_EXCHANGER = "heat_exchanger"
    COMPRESSOR = "compressor"
    VALVE = "valve"
    INSTRUMENT = "instrument"

class Stream(BaseModel):
    """Process stream"""
    id: str
    name: str
    from_equipment: str
    to_equipment: str
    phase: Literal["liquid", "gas", "two_phase"] = "liquid"
    temperature: Optional[float] = None
    pressure: Optional[float] = None
    flowrate: Optional[float] = None
    composition: Optional[Dict[str, float]] = None

class Equipment(BaseModel):
    """Process equipment"""
    id: str
    tag: str  # e.g., "P-101", "V-201"
    type: EquipmentType
    name: str
    description: Optional[str] = None
    specifications: Dict = Field(default_factory=dict)
    position: Optional[tuple[float, float]] = None
    
class Instrument(BaseModel):
    """Control instrument"""
    id: str
    tag: str  # e.g., "FIC-101", "TI-201"
    type: str  # PID, level, pressure, temperature
    measured_variable: str
    controlled_variable: Optional[str] = None
    attached_to: str  # Equipment or stream ID
    position: Optional[tuple[float, float]] = None

class PIDDocument(BaseModel):
    """Complete P&ID document"""
    title: str = "Untitled P&ID"
    drawing_number: str = "001"
    revision: str = "A"
    process_description: str = ""
    equipment: List[Equipment] = Field(default_factory=list)
    streams: List[Stream] = Field(default_factory=list)
    instruments: List[Instrument] = Field(default_factory=list)
    metadata: Dict = Field(default_factory=dict)

class WizardState(BaseModel):
    """Wizard conversation state"""
    step: int = 0
    process_type: Optional[str] = None
    raw_description: str = ""
    clarifications: List[str] = Field(default_factory=list)
    extracted_data: Optional[PIDDocument] = None
    validation_results: Optional[Dict] = None
