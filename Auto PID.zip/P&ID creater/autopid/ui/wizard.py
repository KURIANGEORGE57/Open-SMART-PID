import gradio as gr
from autopid.models.data_models import PIDDocument, Equipment, EquipmentType, Stream
from autopid.rendering.renderer import PIDRenderer
import os

def generate_pid(description):
    # Mock implementation for Phase 1
    # In Phase 2, this will use the Parser Agent
    
    # Create a dummy PID document based on simple keywords
    doc = PIDDocument(process_description=description)
    
    # Simple keyword matching for demo purposes
    desc_lower = description.lower()
    
    if "pump" in desc_lower:
        doc.equipment.append(Equipment(
            id="eq1", tag="P-101", type=EquipmentType.PUMP, name="Feed Pump", 
            position=(100, 300)
        ))
    
    if "vessel" in desc_lower or "tank" in desc_lower:
        doc.equipment.append(Equipment(
            id="eq2", tag="V-101", type=EquipmentType.VESSEL, name="Storage Vessel", 
            position=(300, 300)
        ))
        
    if "exchanger" in desc_lower:
        doc.equipment.append(Equipment(
            id="eq3", tag="E-101", type=EquipmentType.HEAT_EXCHANGER, name="Heat Exchanger", 
            position=(500, 300)
        ))

    # Add a stream if we have at least two pieces of equipment
    if len(doc.equipment) >= 2:
        doc.streams.append(Stream(
            id="s1", name="Feed", from_equipment=doc.equipment[0].id, to_equipment=doc.equipment[1].id
        ))

    # Render
    renderer = PIDRenderer()
    output_path = "generated_pid.svg"
    renderer.render(doc, output_path)
    
    return output_path, doc.model_dump_json(indent=2)

def create_interface():
    with gr.Blocks(theme=gr.themes.Soft()) as app:
        gr.Markdown("# AutoPID: AI-Powered P&ID Generator (Phase 1 Demo)")
        
        with gr.Tab("Create P&ID"):
            description = gr.Textbox(
                label="Describe your process",
                placeholder="Example: I need a pump feeding a vessel.",
                lines=5
            )
            generate_btn = gr.Button("Generate P&ID")
            
            with gr.Row():
                # Gradio Image component doesn't natively support SVG well in all versions, 
                # but we'll try passing the file path. 
                # Alternatively, we could convert to PNG, but let's stick to SVG for now as per plan.
                output_image = gr.Image(label="Generated P&ID", type="filepath") 
                output_data = gr.JSON(label="Extracted Data")
            
            generate_btn.click(
                generate_pid,
                inputs=[description],
                outputs=[output_image, output_data]
            )
            
    return app

if __name__ == "__main__":
    app = create_interface()
    app.launch()
