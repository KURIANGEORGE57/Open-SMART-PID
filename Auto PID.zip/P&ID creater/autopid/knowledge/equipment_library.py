import json
import os
from typing import Dict, Any

class EquipmentLibrary:
    def __init__(self):
        self.data_path = os.path.join(os.path.dirname(__file__), "data", "equipment.json")
        self.equipment_data = self._load_data()

    def _load_data(self) -> Dict[str, Any]:
        if not os.path.exists(self.data_path):
            return {}
        with open(self.data_path, 'r') as f:
            return json.load(f)

    def get_equipment_spec(self, type_name: str, subtype: str = None) -> Dict[str, Any]:
        if type_name not in self.equipment_data:
            return {}
        if subtype and subtype in self.equipment_data[type_name]:
            return self.equipment_data[type_name][subtype]
        # Return first subtype if not specified
        first_key = next(iter(self.equipment_data[type_name]))
        return self.equipment_data[type_name][first_key]
